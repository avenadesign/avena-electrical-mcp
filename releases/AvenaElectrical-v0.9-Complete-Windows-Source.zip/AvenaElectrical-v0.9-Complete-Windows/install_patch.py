"""Pinned, non-destructive overlay installer for U-C4N/Autocad-MCP.

Preserves unrecognized files, tracks hashes for owned files, and refuses
updates/removal when any managed source was edited by the operator.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

BEGIN = "# >>> AVENA ELECTRICAL ADDON >>>"
END = "# <<< AVENA ELECTRICAL ADDON <<<"
COM_BEGIN = "# >>> AVENA ATTACH ONLY >>>"
COM_END = "# <<< AVENA ATTACH ONLY <<<"
INJECTION = (
    f"{BEGIN}\n"
    "import os as _avena_os\n"
    "if _avena_os.environ.get('AVENA_ELECTRICAL_ENABLED', 'false').lower() == 'true':\n"
    "    from engineering.electrical.mcp_tools import register_electrical_tools\n"
    "    register_electrical_tools(mcp)\n"
    f"{END}\n\n"
)
ANCHOR = "\ndef main() -> None:"
COM_ANCHOR = '            log.debug("GetActiveObject(%r) failed, trying Dispatch: %s", progid, exc)'
COM_INJECTION = (
    f"            {COM_BEGIN}\n"
    "            if os.environ.get('AVENA_ATTACH_ONLY', 'false').lower() == 'true':\n"
    "                raise RuntimeError(\n"
    "                    f'AutoCAD {progid!r} is not running; Avena attach-only mode forbids Dispatch.'\n"
    "                ) from exc\n"
    f"            {COM_END}\n"
)
MANIFEST = ".avena_electrical_manifest.json"
LEGACY_SHA256 = {
    "engineering/electrical/mcp_tools.py": "28b158c96ff09b24a9cda568e02db85650cec6dd79eae191c0e2a47f33c64aca",
    "engineering/electrical/__init__.py": "1560a5f68f28f13a709f884ca500a25f26d1af051945d6b8372dcd91fc6a7585",
    "engineering/electrical/audit.py": "c748767519336f5a16e2b2f8b2995089f40f2892278791885bb6340dbc87ed16",
    "engineering/electrical/spec.py": "df0556f91027be79d4bed4ffdc11ed327174089b1a4708cdb5dda1df74821b80",
    "engineering/electrical/sld.py": "b1e16f05f784cc1db09d157e49224d2a4bceaf56b907ed64027ef9937ecbbfee",
    "app/__init__.py": "528167cd3dd085738ab52841ff79f0c46561554ae6704904faccad17d8351d03",
    "app/com_probe.py": "f2a10566e9a3c466043d22447de6cd92864833b71888ce78be370581ff20114d",
    "app/com_inventory.py": "f5df631e67eda6ef2e5e16eef2154e58397ab644c50b65740f7b9440db176d8e",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned_sources() -> dict[str, Path]:
    root = Path(__file__).resolve().parent
    source = root / "engineering" / "electrical"
    paths = {str(p.relative_to(root)).replace("\\", "/"): p for p in source.rglob("*.py")}
    for name in ("__init__.py", "com_probe.py", "com_inventory.py"):
        paths[f"app/{name}"] = root / "app" / name
    return paths


def apply(repo: Path, remove: bool = False) -> str:
    repo = repo.resolve()
    server = repo / "server.py"
    backend = repo / "backends" / "com_backend.py"
    if not server.is_file() or not backend.is_file() or not (repo / "engineering" / "pid").is_dir():
        raise ValueError("Expected U-C4N/Autocad-MCP source checkout")
    source = server.read_text(encoding="utf-8")
    com_source = backend.read_text(encoding="utf-8")
    manifest_path = repo / MANIFEST
    previous = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    old_owned = previous.get("owned", {})
    sources = owned_sources()
    existing = BEGIN in source or COM_BEGIN in com_source
    if existing and not (BEGIN in source and COM_BEGIN in com_source):
        raise ValueError("Partial patch markers; refusing")
    if existing and (source.count("\n" + INJECTION) != 1 or com_source.count(COM_INJECTION) != 1):
        raise ValueError("Unexpected patch body; refusing")
    if not existing and (source.count(ANCHOR) != 1 or com_source.count(COM_ANCHOR) != 1):
        raise ValueError("Unexpected upstream source structure; refusing")
    # Verify all target files BEFORE performing any write.
    for rel, src in sources.items():
        dst = repo / rel
        if dst.exists() and sha(dst) not in {sha(src), old_owned.get(rel), LEGACY_SHA256.get(rel)}:
            raise ValueError(f"Managed file modified or collision: {rel}. Refusing overwrite")
    # For removal, check every manifest-owned file that is still present.
    if remove:
        if not existing:
            return "Already removed."
        if not previous and any((repo / rel).exists() and sha(repo / rel) not in {LEGACY_SHA256.get(rel), sha(src)} for rel, src in sources.items()):
            raise ValueError("Untracked addon changes; cannot remove")
        server.write_text(source.replace("\n" + INJECTION, "", 1), encoding="utf-8")
        backend.write_text(com_source.replace(COM_INJECTION, "", 1), encoding="utf-8")
        for rel, src in sources.items():
            dst = repo / rel
            if dst.is_file() and sha(dst) in {old_owned.get(rel), LEGACY_SHA256.get(rel), sha(src)}:
                dst.unlink()
        if manifest_path.exists():
            manifest_path.unlink()
        return "Addon patch removed; managed files cleaned when unchanged. Inspect git diff."
    if not existing:
        new_server = source.replace(ANCHOR, "\n" + INJECTION + ANCHOR, 1)
        new_backend = com_source.replace(COM_ANCHOR, COM_INJECTION + COM_ANCHOR, 1)
        server.write_text(new_server, encoding="utf-8")
        backend.write_text(new_backend, encoding="utf-8")
    owned = {}
    for rel, src in sources.items():
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.is_file() or sha(dst) != sha(src):
            shutil.copy2(src, dst)
        owned[rel] = sha(dst)
    manifest_path.write_text(json.dumps({"format": 1, "owned": owned}, indent=2) + "\n", encoding="utf-8")
    return "Already installed; checked/upgraded safely." if existing else "Addon installed; COM attach-only enabled on opt-in."


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("repo", type=Path)
    p.add_argument("--remove", action="store_true")
    a = p.parse_args()
    print(apply(a.repo, a.remove))
