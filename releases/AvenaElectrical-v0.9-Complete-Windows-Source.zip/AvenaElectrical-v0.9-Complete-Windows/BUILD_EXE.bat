@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Avena Electrical - BUILD EXE
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Windows PowerShell is required.
  pause
  exit /b 1
)
echo [AVENA] Building from a pinned AutoCAD MCP Pro source...
echo [AVENA] Uses installed Python 3 x64 (>= 3.11). Git is optional.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build_windows.ps1"
set "STATUS=%ERRORLEVEL%"
if "%STATUS%"=="0" (
  echo.
  echo [SUCCESS] EXE: %~dp0dist\AvenaElectrical\AvenaElectrical.exe
) else (
  echo [ERROR] BUILD failed with exit code %STATUS%.
)
pause
exit /b %STATUS%
