"""Smoke-test the cloud bridge without Windows, AutoCAD or external network calls."""
from unittest.mock import patch
from app import cloud_agent


def test_read_only_allowlist():
    assert 'drawing_info' in cloud_agent.ALLOWED
    assert 'layer_list' in cloud_agent.ALLOWED
    for name in ('cad_batch', 'document_save', 'document_close', 'command_send', 'entity_delete'):
        assert name not in cloud_agent.ALLOWED


def test_local_handshake_and_call():
    responses = [
        ({'jsonrpc': '2.0', 'id': 1, 'result': {'protocolVersion': '2025-06-18'}}, 'session'),
        ({}, 'session'),
        ({'jsonrpc': '2.0', 'id': 2, 'result': {'content': [{'type': 'text', 'text': 'ok'}]}}, 'session'),
    ]
    with patch.object(cloud_agent, 'local_post', side_effect=responses) as request:
        result = cloud_agent.call_local('drawing_info', 'TEST_TOKEN')
    assert result['ok'] is True
    assert request.call_count == 3
    assert request.call_args_list[-1].args[0] == 'tools/call'
    assert request.call_args_list[-1].args[1]['name'] == 'drawing_info'


def test_local_error_result():
    responses = [
        ({'result': {'capabilities': {}}}, None),
        ({}, None),
        ({'result': {'isError': True, 'content': [{'type': 'text', 'text': 'failed'}]}}, None),
    ]
    with patch.object(cloud_agent, 'local_post', side_effect=responses):
        assert cloud_agent.call_local('block_list', 'TEST_TOKEN')['ok'] is False


def test_reject_unknown_tool():
    assert cloud_agent.call_local('cad_batch', 'TEST_TOKEN')['error'] == 'tool_not_permitted'
