"""Offline regression checks for Windows bootstrap scripts (no Windows execution)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_python_launcher_uses_latest_installed_3_x64_no_fixed_minor_pin():
    text = (ROOT / "scripts" / "windows_common.ps1").read_text(encoding="utf-8")
    assert "sys.version_info >= (3, 11)" in text
    assert "sys.maxsize > 2**32" in text
    assert "Prefix = @('-3')" in text
    assert "AVENA_PYTHON" in text
    assert "[(3,11),(3,12),(3,13)]" not in text
    assert "Python.Python.3.11" not in text
    assert "winget install" not in text


def test_no_mandatory_py_launcher_or_git_on_first_run():
    text = (ROOT / "scripts" / "run_windows.ps1").read_text(encoding="utf-8")
    common = (ROOT / "scripts" / "windows_common.ps1").read_text(encoding="utf-8")
    assert "Ensure-AvenaPython" in text
    assert "Ensure-AvenaSource" in text
    assert "elc.avenaai.ir/downloads/avena-cad-engine-v1.zip" in common
    assert "Get-Command git" in common  # Git only when verifying a pre-existing checkout
    assert 'py -3.11 -c' not in text


def test_build_bat_uses_same_resolver_and_keeps_exe_mode():
    build = (ROOT / "scripts" / "build_windows.ps1").read_text(encoding="utf-8")
    runbat = (ROOT / "RUN.bat").read_text(encoding="utf-8")
    assert "windows_common.ps1" in build
    assert "Ensure-AvenaPython" in build
    assert "--onedir" in build
    assert "dist\\AvenaElectrical\\AvenaElectrical.exe" in runbat


def test_no_python_minor_pin_in_windows_entry_points():
    for relative_path in (
        "RUN.bat", "BUILD_EXE.bat", "PANEL_REPORT.bat",
        "scripts/run_windows.ps1", "scripts/build_windows.ps1",
        "scripts/windows_common.ps1",
    ):
        data = (ROOT / relative_path).read_text(encoding="utf-8")
        assert "py -3.11" not in data
        assert "py -3.12" not in data
        assert "py -3.13" not in data
    common = (ROOT / "scripts/windows_common.ps1").read_text(encoding="utf-8")
    assert "-m', 'venv'" in common
    assert "Prefix = @('-3')" in common


def test_build_and_run_resolve_same_python():
    for relative_path in ("scripts/run_windows.ps1", "scripts/build_windows.ps1"):
        data = (ROOT / relative_path).read_text(encoding="utf-8")
        assert "Ensure-AvenaVenv" in data
        assert "Ensure-AvenaPython" in data
        assert "windows_common.ps1" in data


def test_existing_venv_does_not_silently_keep_older_python():
    common=(ROOT / "scripts" / "windows_common.ps1").read_text(encoding="utf-8")
    assert "currentFamily" in common and "venvFamily" in common
    for entry in ("scripts/run_windows.ps1", "scripts/build_windows.ps1"):
        script=(ROOT / entry).read_text(encoding="utf-8")
        assert "$Selected = Ensure-AvenaPython" in script
