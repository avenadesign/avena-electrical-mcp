from pathlib import Path
import pytest
from install_patch import apply


def setup_repo(tmp_path):
    (tmp_path / "engineering" / "pid").mkdir(parents=True)
    (tmp_path / "backends").mkdir()
    (tmp_path / "server.py").write_text("before\n\ndef main() -> None:\n    pass\n")
    (tmp_path / "backends" / "com_backend.py").write_text(
        'before\n            log.debug("GetActiveObject(%r) failed, trying Dispatch: %s", progid, exc)\n')
    return tmp_path


def test_patch_reversible_and_idempotent(tmp_path):
    repo=setup_repo(tmp_path)
    original=(repo/"server.py").read_text()
    original_com=(repo/"backends"/"com_backend.py").read_text()
    assert 'installed' in apply(repo).lower()
    assert 'AVENA_ATTACH_ONLY' in (repo/"backends"/"com_backend.py").read_text()
    assert 'Already installed' in apply(repo)
    apply(repo, remove=True)
    assert (repo/"server.py").read_text() == original
    assert (repo/"backends"/"com_backend.py").read_text() == original_com


def test_collision_refused_before_modification(tmp_path):
    repo=setup_repo(tmp_path)
    (repo/"app").mkdir()
    (repo/"app"/"com_probe.py").write_text("user file")
    before=(repo/"server.py").read_text()
    with pytest.raises(ValueError):
        apply(repo)
    assert (repo/"server.py").read_text()==before
