"""Regression: drawing write path must fail closed without a fresh local approval."""
import os
from unittest.mock import patch
import pytest
from app import cloud_agent
from app import drawing_approval as drawings

PLAN=[{"type":"line","args":{"x1":0,"y1":0,"x2":100,"y2":0,"layer":"AVENA_PANEL"}}]

@pytest.mark.parametrize("invalid",[
    [{"type":"entity_delete","args":{"handle":"1"}}],
    [{"type":"line","args":{"x1":0,"y1":0,"x2":10,"y2":False}}],
    [{"type":"circle","args":{"cx":0,"cy":0,"radius":-1}}],
    [{"type":"text","args":{"text":"X\nCOMMAND","x":0,"y":0}}],
    [{"type":"line","args":{"x1":0,"y1":0,"x2":1,"y2":2,"command":"save"}}],
    [{"type":"block_ref","args":{"name":"*Model_Space","x":0,"y":0}}],
    [{"type":"polyline","args":{"points":[[0,0],[float('inf'),1]]}}],
])
def test_invalid_commands_rejected(invalid):
    with pytest.raises(ValueError):drawings.validate_plan(invalid)

def test_plan_approved_on_valid_geometry():
    assert drawings.validate_plan(PLAN)==PLAN
    assert drawings.TOOL_BY_TYPE['line']=='entity_create_line'

def test_no_windows_no_approval():
    if os.name!='nt':assert drawings.approve_on_windows('some.dwg',PLAN) is False

def test_not_allowed_by_default():
    with patch.dict(os.environ,{},clear=True):
        assert cloud_agent.execute_approved_batch(PLAN,'KEY')['error']=='drawing_disabled_in_desktop_settings'

def test_local_rejection_prevents_any_write():
    with patch.dict(os.environ,{'AVENA_DRAW_ENABLED':'1','AVENA_AUTOCAD_RELEASE':'2026','AVENA_ALLOWED_PATHS':'/tmp'}):
        with patch.object(drawings,'verify_active_drawing',return_value='/tmp/a.dwg'), patch.object(drawings,'approve_on_windows',return_value=False), patch.object(cloud_agent,'local_post') as local:
            answer=cloud_agent.execute_approved_batch(PLAN,'KEY')
            assert answer['error']=='rejected_by_local_user_or_timeout'
            local.assert_not_called()

def test_approved_one_additive_write_only():
    res=[({'result':{'protocolVersion':'2025-06-18'}},'session'),({},'session'),({'result':{'content':[{'type':'text','text':'created'}]}},'session')]
    with patch.dict(os.environ,{'AVENA_DRAW_ENABLED':'1','AVENA_AUTOCAD_RELEASE':'2026','AVENA_ALLOWED_PATHS':'/tmp'}):
        with patch.object(drawings,'verify_active_drawing',return_value='/tmp/a.dwg'), patch.object(drawings,'approve_on_windows',return_value=True), patch.object(cloud_agent,'local_post',side_effect=res) as local:
            answer=cloud_agent.execute_approved_batch(PLAN,'KEY')
            assert answer['ok'] is True
            assert answer['created_count']==1
            assert answer['saved'] is False
            assert local.call_args_list[-1].args[1]['name']=='entity_create_line'
            assert all('document_save' not in str(x) for x in local.call_args_list)

def test_partial_result_not_reported_success():
    res=[({'result':{'protocolVersion':'2025-06-18'}},'session'),({},'session'),({'result':{'isError':True,'content':[]}},'session')]
    with patch.dict(os.environ,{'AVENA_DRAW_ENABLED':'1','AVENA_AUTOCAD_RELEASE':'2026','AVENA_ALLOWED_PATHS':'/tmp'}):
        with patch.object(drawings,'verify_active_drawing',return_value='/tmp/a.dwg'), patch.object(drawings,'approve_on_windows',return_value=True), patch.object(cloud_agent,'local_post',side_effect=res):
            answer=cloud_agent.execute_approved_batch(PLAN,'KEY')
            assert answer['ok'] is False
            assert answer['created_count']==0

def test_more_than_ten_requires_new_batch():
    with patch.dict(os.environ,{'AVENA_DRAW_ENABLED':'1'}):
        assert cloud_agent.execute_approved_batch(PLAN*11,'KEY')['error']=='preflight_failed'
