from unittest.mock import patch
import pytest
from app import edit_approval,cloud_agent

BASE=[{'type':'move','args':{'handle':'AF10','dx':10.0,'dy':5.0}}]

def test_valid_edit():
    assert edit_approval.validate_edits(BASE)==BASE
    assert edit_approval.TOOLS['properties']=='entity_set_properties'

@pytest.mark.parametrize('operations',[
    [{'type':'delete','args':{'handle':'A1'}}],
    [{'type':'move','args':{'handle':'bad!', 'dx':1,'dy':1}}],
    [{'type':'text','args':{'handle':'AC','text':'x\nCOMMAND'}}],
    [{'type':'properties','args':{'handle':'A','layer':'a','visible':False}}],
    [{'type':'properties','args':{'handle':'A','layer':'a','color':999}}],
    BASE*9,
])
def test_invalid_edit_rejected(operations):
    with pytest.raises(ValueError):edit_approval.validate_edits(operations)

def test_unapproved_edit_has_no_mcp_calls():
    with patch.dict('os.environ',{'AVENA_DRAW_ENABLED':'1','AVENA_AUTOCAD_RELEASE':'2026','AVENA_ALLOWED_PATHS':'/tmp'}):
        with patch('app.drawing_approval.verify_active_drawing',return_value='/tmp/a.dwg'),patch('app.drawing_approval.approve_on_windows',return_value=False),patch.object(cloud_agent,'local_post') as rpc:
            result=cloud_agent.execute_approved_edits(BASE,'local-key')
            assert result['error']=='rejected_by_local_user_or_timeout'
            rpc.assert_not_called()

def test_approved_edit_calls_exact_tool():
    outcomes=[({'result':{}},'s1'),({},'s1'),({'result':{'content':[]}},'s1')]
    with patch.dict('os.environ',{'AVENA_DRAW_ENABLED':'1','AVENA_AUTOCAD_RELEASE':'2026','AVENA_ALLOWED_PATHS':'/tmp'}):
        with patch('app.drawing_approval.verify_active_drawing',return_value='/tmp/a.dwg'),patch('app.drawing_approval.approve_on_windows',return_value=True),patch.object(cloud_agent,'local_post',side_effect=outcomes) as rpc:
            result=cloud_agent.execute_approved_edits(BASE,'local-key')
            assert result['ok'] and not result['saved']
            assert rpc.call_args_list[-1].args[1]['name']=='entity_move'
