import copy
import csv
import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from engineering.electrical.panel_pro import PanelPro, audit_panel_pro
from engineering.electrical.panel_pro_outputs import bom, bom_csv, feeder_schedule_csv, panel_sld_drafts
from engineering.electrical.panel_pro_mcp import register_panel_pro_tools
from app.panel_cli import reports

SAMPLE = Path(__file__).parents[1] / "examples" / "panel_pro_db01.json"


def spec():
    return json.loads(SAMPLE.read_text(encoding="utf-8"))


def codes(data):
    return {f["code"] for f in audit_panel_pro(PanelPro.model_validate(data))["findings"]}


def test_example_preflight_never_certifies():
    result = audit_panel_pro(PanelPro.model_validate(spec()))
    assert result["engineering_approval"] is False
    assert result["status"] == "preliminary_only"
    assert result["total_connected_kw"] == pytest.approx(11.7)
    assert result["counts"]["unknown"] >= 3
    assert "assembly_verification_not_automatic" in {f["code"] for f in result["findings"]}


def test_incoming_rating_fails():
    d = spec(); d["incoming_device"]["rated_current_a"] = 2
    assert "incoming_rating_below_phase_current" in codes(d)


def test_bars_peak_rating_fails():
    d = spec(); d["busbar_rated_current_a"] = 1
    assert "busbar_current_exceeded" in codes(d)


def test_busbar_fault_withstand_fails():
    d = spec(); d["busbar_withstand_ka"] = 5
    assert "busbar_fault_rating_exceeded" in codes(d)


def test_incoming_breaking_rating_fails():
    d = spec(); d["incoming_device"]["breaking_capacity_ka"] = 5
    assert "incoming_breaking_capacity_insufficient" in codes(d)


def test_feeder_breaking_rating_fails():
    d = spec(); d["feeders"][0]["protection"]["breaking_capacity_ka"] = 2
    assert "breaking_capacity_insufficient" in codes(d)


def test_no_breaking_capacity_is_unknown_not_pass():
    d = spec(); d["feeders"][0]["protection"]["breaking_capacity_ka"] = None
    result = audit_panel_pro(PanelPro.model_validate(d))
    assert "device_breaking_capacity_missing" in [x["code"] for x in result["findings"] if x["status"] == "unknown"]


def test_missing_thermal_evidence_is_unknown():
    assert "thermal_evidence_missing" in codes(spec())


def test_declared_thermal_budget_exceeded():
    d = spec(); d["enclosure_allowed_heat_w"] = 20; d["incoming_device_loss_w"] = 10
    for f in d["feeders"]: f["device_loss_w"] = 10
    assert "declared_heat_budget_exceeded" in codes(d)


def test_din_capacity_overflow():
    d = spec(); d["available_din_modules"] = 3
    assert "din_capacity_exceeded" in codes(d)


def test_minimum_din_reserve():
    d = spec(); d["minimum_spare_din_modules"] = 70
    assert "spare_modules_insufficient" in codes(d)


def test_loop_impedance_exceeds_supplied_threshold():
    d = spec(); d["feeders"][0]["earth_loop_impedance_ohm"] = 2
    d["feeders"][0]["approved_max_loop_impedance_ohm"] = 0.8
    assert "earth_loop_threshold_exceeded" in codes(d)


def test_unpaired_loop_rejected():
    d = spec(); d["feeders"][0]["earth_loop_impedance_ohm"] = 1
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_unpaired_cable_rx_rejected():
    d = spec(); d["feeders"][0]["cable_x_ohm_km"] = None
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_feeder_voltage_mismatch():
    d = spec(); d["feeders"][0]["voltage_v"] = 400
    assert "feeder_voltage_mismatch" in codes(d)


def test_cable_ampacity_issue():
    d = spec(); d["feeders"][0]["cable_corrected_ampacity_a"] = 1
    assert "ib_gt_iz" in codes(d)


def test_voltage_drop_limit_issue():
    d = spec(); d["feeders"][0]["max_voltage_drop_pct"] = 0.01
    assert "voltage_drop_exceeded" in codes(d)


def test_duplicate_device_tags_rejected():
    d = spec(); d["feeders"][0]["protection"]["tag"] = d["incoming_device"]["tag"]
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_nan_rejected():
    d = spec(); d["feeders"][0]["connected_kw"] = float("nan")
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_no_neutral_rejects_1p_feeder():
    d = spec(); d["phases"] = "3P"
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_unknown_property_rejected():
    d = spec(); d["shell_command"] = "erase all"
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_bom_counts_consistent():
    b = bom(PanelPro.model_validate(spec()))
    assert b["component_count"] == 5
    assert len(b["cables"]) == 4
    assert all(x["estimate_only"] for x in b["cables"])


def test_csv_formula_injection_escaped():
    d = spec(); d["feeders"][0]["protection"]["manufacturer"] = "=HYPERLINK(\"x\")"
    output = bom_csv(PanelPro.model_validate(d))
    records = list(csv.DictReader(output.splitlines()))
    assert any(row["manufacturer"].startswith("'=HYPERLINK") for row in records)


def test_feeder_schedule_csv_rows():
    raw = feeder_schedule_csv(PanelPro.model_validate(spec()))
    assert len(list(csv.DictReader(raw.splitlines()))) == 4


def test_paged_sld_pure_plan():
    p = panel_sld_drafts(PanelPro.model_validate(spec()), per_sheet=2)
    assert p["sheet_count"] == 2
    assert not p["native_electrical_symbols"]
    assert all(s["step_count"] <= 250 and s["batch"]["dry_run"] for s in p["sheets"])
    assert "cad_batch" in p["procedure"]


def test_max_feeder_count_many_pages():
    d = spec()
    base = d["feeders"][0]
    d["feeders"] = []
    for i in range(256):
        row = copy.deepcopy(base); row["id"] = f"C{i:03d}"; row["protection"]["tag"] = f"Q{i:03d}"
        d["feeders"].append(row)
    p = panel_sld_drafts(PanelPro.model_validate(d))
    assert p["sheet_count"] == 32
    assert all(s["step_count"] <= 250 for s in p["sheets"])


def test_mcp_tools_are_readonly():
    class Dummy:
        def __init__(self): self.tools={}
        def tool(self, **kw):
            def add(fn): self.tools[kw["name"]] = (fn, kw); return fn
            return add
    dummy = Dummy(); register_panel_pro_tools(dummy)
    assert len(dummy.tools) == 4
    assert all(meta["annotations"]["readOnlyHint"] for fn, meta in dummy.tools.values())
    assert dummy.tools["electrical_panel_pro_audit"][0](spec())["engineering_approval"] is False


def test_reports_generated_readonly(tmp_path):
    res = reports(SAMPLE, tmp_path)
    assert res["status"] == "preliminary_only"
    assert len(res["files"]) == 5
    assert (tmp_path / "panel_bom.csv").exists()
    assert json.loads((tmp_path / "panel_sld_previews.json").read_text())["sheet_count"] == 1


def test_missing_assembly_reference_flag():
    assert "design_verification_missing" in codes(spec())


def test_electrical_only_isolate_not_claim_overcurrent():
    d = spec(); d["incoming_device"]["kind"] = "ISOLATOR"
    assert "incoming_short_circuit_protection_unverified" in codes(d)


def test_single_phase_with_multiple_phases_rejected():
    d = spec(); d["phases"] = "1P+N"
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_local_font_not_required_for_tests():
    from app.font_loader import register_local_font
    import sys
    if sys.platform != 'win32':
        assert register_local_font() is False


def test_windows_batch_entrypoints_present():
    root = Path(__file__).parents[1]
    for name in ('RUN.bat', 'BUILD_EXE.bat', 'PANEL_REPORT.bat'):
        f = root / name
        assert f.is_file() and f.read_text().startswith('@echo off')
    assert (root / 'scripts' / 'run_windows.ps1').is_file()
    assert (root / 'scripts' / 'build_windows.ps1').is_file()


def test_accessory_din_width_budget():
    d=spec()
    d['auxiliaries']=[{'tag':'SPD-01','kind':'SPD','quantity':2,'width_modules_each':40}]
    assert 'din_capacity_exceeded' in codes(d)


def test_accessory_bom_quantity():
    d=spec()
    d['auxiliaries']=[{'tag':'CT-GROUP','kind':'CT','quantity':3,'manufacturer':'ACME'}]
    b=bom(PanelPro.model_validate(d))
    assert b['component_count'] == 8
    assert any(row['kind']=='CT' and row['quantity']==3 for row in b['components'])


def test_accessory_tag_collision_rejected():
    d=spec()
    d['auxiliaries']=[{'tag':'QF-01','kind':'SPD','quantity':1}]
    with pytest.raises(ValidationError): PanelPro.model_validate(d)


def test_rcbo_without_residual_rating_is_unknown():
    d=spec(); d['feeders'][1]['protection']['residual_trip_ma']=None
    assert 'residual_trip_rating_missing' in codes(d)


def test_tt_requires_earth_fault_protection_evidence():
    d=spec(); d['system']='TT'
    d['feeders'][1]['protection']['kind']='MCB'
    d['feeders'][1]['protection']['residual_trip_ma']=None
    assert 'tt_residual_protection_not_documented' in codes(d)
