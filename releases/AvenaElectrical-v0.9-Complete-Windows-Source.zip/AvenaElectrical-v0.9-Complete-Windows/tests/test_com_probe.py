from app.com_probe import CAD_PROGIDS, probe
from app.runner import mcp_environment
import pytest


def test_progid_versions():
    assert CAD_PROGIDS == {"2026": "AutoCAD.Application.25.1", "2027": "AutoCAD.Application.26"}


def test_unsupported_release_refused():
    with pytest.raises(ValueError):
        probe("2025")


def test_probe_on_nonwindows_is_read_only():
    import sys
    if sys.platform != "win32":
        x = probe("2027")
        assert not x.attached
        assert not x.available


def test_mcp_environment_pins_version_and_security(tmp_path):
    e=mcp_environment("2027",str(tmp_path),"a"*48)
    assert e["CAD_PROGID"] == "AutoCAD.Application.26"
    assert e["AUTOCAD_MCP_BACKEND"] == "com"
    assert e["ALLOW_REMOTE_HTTP"] == "false"
    assert e["DANGEROUS_COMMANDS_ENABLED"] == "false"
    assert e["MCP_AUTH_TOKEN"] == "a"*48


def test_mcp_environment_rejects_short_token(tmp_path):
    with pytest.raises(ValueError):
        mcp_environment("2026",str(tmp_path),"short")


def test_mcp_environment_rejects_missing_path(tmp_path):
    with pytest.raises(ValueError):
        mcp_environment("2027",str(tmp_path/"missing"),"b"*40)
