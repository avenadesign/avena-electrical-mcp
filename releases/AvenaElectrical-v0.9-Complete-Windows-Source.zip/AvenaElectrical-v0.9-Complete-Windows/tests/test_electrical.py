"""Run with: PYTHONPATH=. pytest -q tests/test_electrical.py (from addon root)."""

import pytest
from pydantic import ValidationError

from engineering.electrical import PanelSpec, RiserSpec, audit_panel, audit_riser, plan_sld


def circuit(phase="L1", ident="C1", **overrides):
    data = {
        "id": ident, "phase": phase, "input_load_kw": 2.3,
        "nominal_voltage_v": 230 if phase != "3P" else 400,
        "power_factor": 1, "demand_factor": 1, "length_m": 10,
    }
    data.update(overrides)
    return data


def panel(circuits=None):
    return PanelSpec.model_validate({"panel_id": "DB1", "circuits": circuits or [circuit()]})


def test_single_phase_current_10_a():
    report = audit_panel(panel())
    assert report["circuits"][0]["design_current_a"] == 10
    assert report["phase_current_a"] == {"L1": 10, "L2": 0, "L3": 0}
    assert report["engineering_approval"] is False


def test_three_phase_current():
    report = audit_panel(panel([circuit("3P", input_load_kw=6.92820323, nominal_voltage_v=400)]))
    assert report["circuits"][0]["design_current_a"] == pytest.approx(10, abs=0.0001)
    assert all(v == pytest.approx(10, abs=0.0001) for v in report["phase_current_a"].values())


def test_voltage_drop_single_phase():
    report = audit_panel(panel([circuit(cable_r_ohm_per_km=2, cable_x_ohm_per_km=0, permitted_voltage_drop_percent=1)]))
    # 2 conductors x 10 A x 10 m / 1000 x 2 ohm/km = 0.4 V.
    assert report["circuits"][0]["voltage_drop_v"] == 0.4
    assert not any(f["code"] == "voltage_drop_exceeded" for f in report["findings"])


def test_breaker_ampacity_issue():
    p = panel([circuit(protective_device_a=8, corrected_ampacity_a=9)])
    codes = {f["code"] for f in audit_panel(p)["findings"]}
    assert {"ib_gt_in", "ib_gt_iz"} <= codes


def test_duplicate_ids_rejected():
    with pytest.raises(ValidationError):
        panel([circuit(ident="c1"), circuit(ident="C1")])


def test_non_finite_rejected():
    with pytest.raises(ValidationError):
        panel([circuit(input_load_kw=float("nan"))])


def test_topology_cycle_and_missing_parent():
    p = RiserSpec.model_validate({"nodes": [
        {"panel_id": "A", "upstream_id": "B"},
        {"panel_id": "B", "upstream_id": "A"},
        {"panel_id": "C", "upstream_id": "MISSING"},
    ]})
    codes = {f["code"] for f in audit_riser(p)["findings"]}
    assert "cycle" in codes and "unknown_upstream" in codes and "root_count" in codes


def test_sld_plan_never_mutates_and_within_batch_limit():
    spec = panel([circuit(ident=f"C{i:02d}") for i in range(1, 33)])
    p = plan_sld(spec)
    assert p["step_count"] <= 250
    assert p["batch"]["dry_run"] is True
    assert p["native_wire_networks"] is False
    assert all(x["tool"] in {
        "layer_create", "entity_create_line", "entity_create_rectangle", "entity_create_text"
    } for x in p["batch"]["steps"])


def test_input_blocked_if_unknown_property():
    with pytest.raises(ValidationError):
        panel([circuit(unsafe_executable_command="(command \"erase\")")])


def test_valid_radial_riser():
    data = RiserSpec.model_validate({"nodes": [
        {"panel_id": "MDB"},
        {"panel_id": "DB1", "upstream_id": "MDB"},
        {"panel_id": "DB2", "upstream_id": "MDB"},
    ]})
    result = audit_riser(data)
    assert result["valid_topology"] is True
    assert result["roots"] == ["MDB"]


def test_missing_impedance_is_unknown_not_pass():
    result = audit_panel(panel())
    assert result["circuits"][0]["voltage_drop_percent"] is None
    assert "impedance_missing" in {f["code"] for f in result["findings"]}


def test_mcp_registration_surface_is_read_only():
    from engineering.electrical.mcp_tools import register_electrical_tools

    class DummyMCP:
        def __init__(self):
            self.tools = {}
        def tool(self, **kwargs):
            def decorator(func):
                self.tools[kwargs["name"]] = (func, kwargs)
                return func
            return decorator

    mcp = DummyMCP()
    register_electrical_tools(mcp)
    assert set(mcp.tools) == {
        "electrical_panel_audit", "electrical_riser_audit", "electrical_sld_plan", "electrical_com_inventory",
        "electrical_panel_pro_audit", "electrical_panel_pro_bom", "electrical_panel_pro_feeder_csv",
        "electrical_panel_pro_sld_pages"
    }
    assert all(args["annotations"]["readOnlyHint"] for _, args in mcp.tools.values())
    assert mcp.tools["electrical_panel_audit"][0](panel().model_dump())["panel_id"] == "DB1"
