"""Offline regression coverage for first-run license and auto-connect policy."""
import pytest
from app.activation_gate import format_code
from app.gui import ControlCenter
from unittest.mock import patch


def test_code_accepts_hyphens_whitespace_and_case():
    assert format_code('abcd-efgh-2345-qwer-789a') == 'ABCD-EFGH-2345-QWER-789A'
    assert format_code('ABCDEFGHIJKLMNOPQRST') == 'ABCD-EFGH-IJKL-MNOP-QRST'


@pytest.mark.parametrize('bad', ['', '123', 'A'*19, 'A'*21, 'A'*10+'!'+'A'*9, 'A'*19+'!'])
def test_code_rejects_malformed(bad):
    with pytest.raises(ValueError):
        format_code(bad)


def test_autocad_not_running_keeps_app_licensed_and_waits():
    center = object.__new__(ControlCenter)
    center._licensed = True
    center._cloud_manual_stop = False
    center.release = type('Variable', (), {'get': lambda self: '2027'})()
    center.proc = None
    center._last_auto_message = None
    recorded = []
    center.root = type('Root', (), {'after': lambda self, delay, cb: recorded.append(delay)})()
    center.cloud_status_label = type('Label', (), {'configure': lambda self, **kw: recorded.append(kw.get('text'))})()
    center.log = lambda msg: recorded.append(msg)
    with patch('app.gui.probe') as probe:
        probe.return_value.available = False
        center._auto_connect()
    assert probe.call_count == 2
    assert 15000 in recorded
    assert any('منتظر' in str(x) for x in recorded)
