$ErrorActionPreference='Stop'
Set-Location (Join-Path $PSScriptRoot '..')
function PickPython {
  if (Get-Command py -ErrorAction SilentlyContinue) { return @('py','-3') }
  if (Get-Command python -ErrorAction SilentlyContinue) { return @('python') }
  throw 'Python 3.11+ 64-bit is required.'
}
try {
  $Selected=PickPython
  $Python=$Selected[0]
  $PArgs=@()
  if ($Selected.Count -gt 1) { $PArgs=@($Selected[1]) }
  & $Python @PArgs -c 'import sys; assert sys.version_info >= (3,11) and sys.maxsize > 2**32'
  if ($LASTEXITCODE -ne 0) { throw 'Python 3.11+ x64 required.' }
  Write-Host '[AVENA] Get your pairing code at: https://elc.avenaai.ir/connect' -ForegroundColor Cyan
  $code=Read-Host 'Enter 20-character pairing code (leave empty if already paired)'
  $localToken=Read-Host 'Enter local MCP bearer token (from Copy Secure Connection in Avena GUI)'
  $env:AVENA_ACTIVATION_CODE=$code
  $env:AVENA_LOCAL_MCP_TOKEN=$localToken
  $env:PYTHONPATH=(Get-Location).Path
  & $Python @PArgs -m app.cloud_agent
  if ($LASTEXITCODE -ne 0) { throw 'Cloud agent stopped.' }
} catch { Write-Host ('[AVENA] '+$_.Exception.Message) -ForegroundColor Red; exit 1 }
finally { Remove-Item Env:AVENA_ACTIVATION_CODE -ErrorAction SilentlyContinue; Remove-Item Env:AVENA_LOCAL_MCP_TOKEN -ErrorAction SilentlyContinue }
