# Avena Electrical Windows setup helpers. PowerShell 5.1+; Windows x64.
# Uses the newest available Python 3 interpreter; no fixed minor-version pin.
# Python >= 3.11 x64 is required for the current dependency stack.
$AvenaPinnedCommit = '58a05ddfc34a9832c626e82cd88ecdce8e16a62a'
$AvenaPythonValidation = 'import sys; sys.exit(0 if (sys.version_info >= (3, 11) and sys.maxsize > 2**32) else 6)'

function Test-AvenaPythonCandidate([string]$Executable, [string[]]$PrefixArgs) {
    if (-not (Get-Command $Executable -ErrorAction SilentlyContinue)) { return $false }
    $argsForProbe = @($PrefixArgs) + @('-c', $AvenaPythonValidation)
    try {
        & $Executable @argsForProbe *> $null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

function Find-AvenaPython {
    # AVENA_PYTHON allows an explicit interpreter path; otherwise prefer the
    # newest registered Python 3 using the Windows Python launcher.
    $items = New-Object System.Collections.ArrayList
    if (-not [string]::IsNullOrWhiteSpace($env:AVENA_PYTHON)) {
        [void]$items.Add(@{ Executable = $env:AVENA_PYTHON.Trim('"'); Prefix = @() })
    }
    # `py -3` chooses the latest installed Python 3 (e.g. 3.13.15).
    # No fixed -3.11 / -3.12 / -3.13 or upper-version restriction.
    [void]$items.Add(@{ Executable = 'py'; Prefix = @('-3') })
    [void]$items.Add(@{ Executable = 'py'; Prefix = @() })
    foreach ($name in @('python', 'python3')) {
        [void]$items.Add(@{ Executable = $name; Prefix = @() })
    }
    foreach ($candidate in $items) {
        if (Test-AvenaPythonCandidate ([string]$candidate.Executable) ([string[]]$candidate.Prefix)) {
            return @{ Executable = [string]$candidate.Executable; Prefix = [string[]]$candidate.Prefix }
        }
    }
    return $null
}

function Ensure-AvenaPython {
    $selected = Find-AvenaPython
    if ($selected) {
        $versionArgs = @($selected.Prefix) + @('-c', 'import sys;print(sys.version_info[0],sys.version_info[1],sys.version_info[2])')
        $runtime = (& $selected.Executable @versionArgs | Select-Object -First 1)
        Write-Host "[AVENA] Using installed Python $runtime" -ForegroundColor Green
        return $selected
    }
    # No silent Python installs or changes to global Python installations.
    throw 'No compatible 64-bit Python >= 3.11 found. Run: py --version ; py -0p . If installed, set AVENA_PYTHON to its full python.exe path.'
}

function Test-AvenaVenv([string]$PythonExe) {
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { return $false }
    return (Test-AvenaPythonCandidate $PythonExe @())
}

function Ensure-AvenaVenv([string]$BuildRoot, $SelectedPython) {
    $venv = Join-Path $BuildRoot '.venv'
    $exe = Join-Path $venv 'Scripts\python.exe'
    if (Test-AvenaVenv $exe) {
        if (-not $SelectedPython) { $SelectedPython = Ensure-AvenaPython }
        $familyArgs = @($SelectedPython.Prefix) + @('-c', 'import sys;print(sys.version_info[0],sys.version_info[1])')
        $currentFamily = (& $SelectedPython.Executable @familyArgs | Select-Object -First 1)
        $venvFamily = (& $exe -c 'import sys;print(sys.version_info[0],sys.version_info[1])' | Select-Object -First 1)
        if ($LASTEXITCODE -ne 0 -or -not $currentFamily -or -not $venvFamily) { throw 'Could not inspect existing venv interpreter.' }
        if (([string]$currentFamily).Trim() -ne ([string]$venvFamily).Trim()) {
            throw "Installed Python is $currentFamily but .build\.venv uses $venvFamily. To use your current Python, rename .build\.venv (do not delete other project files) and rerun RUN.bat."
        }
        return $exe
    }
    if (Test-Path $venv) {
        throw "Existing .build\.venv cannot run or has Python older than 3.11 / non-x64: $venv . Rename/remove that virtual environment only, then re-run RUN.bat."
    }
    if (-not $SelectedPython) { $SelectedPython = Ensure-AvenaPython }
    New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
    $createArgs = @($SelectedPython.Prefix) + @('-m', 'venv', $venv)
    Write-Host '[AVENA] Creating isolated Python virtual environment...'
    & $SelectedPython.Executable @createArgs
    if ($LASTEXITCODE -ne 0 -or -not (Test-AvenaVenv $exe)) {
        throw 'Could not create Python virtual environment (venv).'
    }
    return $exe
}

function Ensure-AvenaSource([string]$BuildRoot, [string]$Repo) {
    $marker = Join-Path $Repo '.avena_pinned_source'
    if (Test-Path -LiteralPath $Repo) {
        $validLayout = (Test-Path (Join-Path $Repo 'server.py')) -and (Test-Path (Join-Path $Repo 'pyproject.toml'))
        if (-not $validLayout) { throw "Source directory exists but is incomplete. Refusing to overwrite: $Repo" }
        if ((Test-Path $marker) -and ((Get-Content $marker -Raw).Trim() -eq $AvenaPinnedCommit)) {
            Write-Host '[AVENA] Using existing pinned upstream source (Git-free cache).'
            return $Repo
        }
        if (Test-Path (Join-Path $Repo '.git')) {
            if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
                throw 'This existing upstream folder is a Git checkout. Install Git to verify its revision or use a fresh folder for ZIP-based install.'
            }
            $head = (& git -C $Repo rev-parse HEAD).Trim()
            if ($LASTEXITCODE -ne 0) { throw 'Could not verify the Git checkout revision.' }
            if ($head -ne $AvenaPinnedCommit) {
                $dirty = & git -C $Repo status --porcelain
                if ($LASTEXITCODE -ne 0 -or $dirty) {
                    throw 'Source checkout modified; refusing to switch to pinned commit and overwrite files.'
                }
                & git -C $Repo fetch origin $AvenaPinnedCommit
                if ($LASTEXITCODE -ne 0) { throw 'Could not fetch pinned upstream commit.' }
                & git -C $Repo checkout --detach $AvenaPinnedCommit
                if ($LASTEXITCODE -ne 0) { throw 'Could not checkout pinned upstream commit.' }
            }
            return $Repo
        }
        throw "Cannot verify existing CAD engine folder $Repo. Back it up manually if needed, then rename it and retry."
    }
    # No Git required for fresh install: download the pinned, license-preserving engine from Avena-owned hosting.
    New-Item -ItemType Directory -Force -Path $BuildRoot | Out-Null
    $zip = Join-Path $BuildRoot "upstream-$AvenaPinnedCommit.zip"
    $staging = Join-Path $BuildRoot '_source_extract'
    if (-not (Test-Path -LiteralPath $zip -PathType Leaf)) {
        $url = "https://elc.avenaai.ir/downloads/avena-cad-engine-v1.zip"
        Write-Host '[AVENA] Downloading Avena CAD engine from elc.avenaai.ir...'
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing -ErrorAction Stop
        } catch {
            Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
            throw "Could not download Avena CAD engine from elc.avenaai.ir. $($_.Exception.Message)"
        }
    }
    if (Test-Path $staging) { throw "Staging directory already exists; refusing deletion: $staging" }
    New-Item -ItemType Directory -Path $staging | Out-Null
    try {
        Expand-Archive -LiteralPath $zip -DestinationPath $staging -ErrorAction Stop
        $matches = @(Get-ChildItem $staging -Directory | Where-Object {
            (Test-Path (Join-Path $_.FullName 'server.py')) -and (Test-Path (Join-Path $_.FullName 'pyproject.toml'))
        })
        if ($matches.Count -ne 1) { throw 'Downloaded upstream archive did not contain exactly one valid project root.' }
        Move-Item -LiteralPath $matches[0].FullName -Destination $Repo -ErrorAction Stop
        [IO.File]::WriteAllText($marker, "$AvenaPinnedCommit`n", (New-Object Text.UTF8Encoding($false)))
    } finally {
        if (Test-Path $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
    }
    return $Repo
}
