$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'windows_common.ps1')
$Addon = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Root = Join-Path $Addon '.build'
$Repo = Join-Path $Root 'Autocad-MCP'

try {
    Write-Host '[AVENA] Checking prerequisites...' -ForegroundColor Cyan
    $Selected = Ensure-AvenaPython
    $Repo = Ensure-AvenaSource $Root $Repo
    $Exe = Ensure-AvenaVenv $Root $Selected
    $env:PYTHONPATH = "$Addon;$Repo"
    New-Item -ItemType Directory -Force -Path (Join-Path $HOME 'Documents\AutoCAD') | Out-Null
    & $Exe -c 'import fastmcp, ezdxf, pydantic, pythoncom, pytest, server'
    if ($LASTEXITCODE -ne 0) {
        Write-Host '[AVENA] Installing required Python packages...' -ForegroundColor Cyan
        & $Exe -m pip install -e "${Repo}[full]" pytest
        if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed (PyPI/network error).' }
    }
    & $Exe (Join-Path $Addon 'install_patch.py') $Repo
    if ($LASTEXITCODE -ne 0) { throw 'Could not safely install Avena overlay.' }
    Write-Host '[AVENA] Running extension tests...'
    & $Exe -m pytest (Join-Path $Addon 'tests') -q
    if ($LASTEXITCODE -ne 0) { throw 'Avena extension tests failed.' }
    Write-Host '[AVENA] Opening Avena Electrical...' -ForegroundColor Green
    & $Exe -m app.main
    if ($LASTEXITCODE -ne 0) { throw "Avena GUI stopped with exit code $LASTEXITCODE" }
} catch {
    Write-Host "[AVENA] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
