$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'windows_common.ps1')
$Addon = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Root = Join-Path $Addon '.build'
$Repo = Join-Path $Root 'Autocad-MCP'

try {
    $Selected = Ensure-AvenaPython
    $Repo = Ensure-AvenaSource $Root $Repo
    $Exe = Ensure-AvenaVenv $Root $Selected
    $env:PYTHONPATH = "$Addon;$Repo"
    & $Exe -m pip install -e "${Repo}[full]" pyinstaller pytest
    if ($LASTEXITCODE -ne 0) { throw 'Could not install build dependencies.' }
    & $Exe (Join-Path $Addon 'install_patch.py') $Repo
    if ($LASTEXITCODE -ne 0) { throw 'Avena overlay failed.' }
    & $Exe -m pytest (Join-Path $Addon 'tests') -q
    if ($LASTEXITCODE -ne 0) { throw 'Extension tests failed.' }
    & $Exe -m PyInstaller --noconfirm --clean --onedir --windowed --name AvenaElectrical `
        --paths $Addon --paths $Repo `
        --collect-all fastmcp --collect-all ezdxf --collect-submodules backends `
        --add-data "${Repo}\templates;templates" `
        --add-data "${Repo}\engineering\recipes\data;engineering/recipes/data" `
        --collect-submodules engineering --collect-submodules discovery `
        --collect-submodules win32com --collect-submodules pydantic `
        --hidden-import=server --hidden-import=config --hidden-import=version `
        --hidden-import=pythoncom --hidden-import=pywintypes `
        --distpath (Join-Path $Addon 'dist') --workpath (Join-Path $Root 'pyinstaller') `
        --specpath $Root (Join-Path $Addon 'app\main.py')
    if ($LASTEXITCODE -ne 0) { throw 'PyInstaller failed. Inspect the visible build log.' }
    Write-Host "BUILT: $Addon\dist\AvenaElectrical\AvenaElectrical.exe" -ForegroundColor Green
} catch {
    Write-Host "[AVENA] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
