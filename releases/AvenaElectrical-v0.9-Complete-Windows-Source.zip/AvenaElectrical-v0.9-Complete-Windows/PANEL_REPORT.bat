@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Avena Electrical - Expert Panel Report
if "%~1"=="" (
  echo Drag a PanelPro JSON file onto this BAT to generate reports.
  echo Example: PANEL_REPORT.bat examples\panel_pro_db01.json
  pause
  exit /b 2
)
if not exist "%~dp0.build\.venv\Scripts\python.exe" (
  echo [AVENA] Python virtual environment has not been prepared.
  echo [AVENA] Double-click RUN.bat first to install dependencies, then retry this report.
  pause
  exit /b 2
)
"%~dp0.build\.venv\Scripts\python.exe" -m app.panel_cli "%~1" --out "%~dp0panel-reports"
set "STATUS=%ERRORLEVEL%"
if "%STATUS%"=="0" echo Reports in %~dp0panel-reports
pause
exit /b %STATUS%
