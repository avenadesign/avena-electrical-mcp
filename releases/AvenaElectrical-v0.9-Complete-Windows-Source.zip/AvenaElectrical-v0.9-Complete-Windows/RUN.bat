@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Avena Electrical - RUN
if not exist "%~dp0app\main.py" if exist "%~dp0dist\AvenaElectrical\AvenaElectrical.exe" (
  echo [AVENA] Starting packaged executable...
  start "Avena Electrical" "%~dp0dist\AvenaElectrical\AvenaElectrical.exe"
  exit /b 0
)
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Windows PowerShell is required.
  pause
  exit /b 1
)
echo [AVENA] Starting newest Avena source (use BUILD_EXE.bat to rebuild any older EXE).
echo [AVENA] Checking installed Python 3 x64 (>= 3.11) and pinned AutoCAD MCP source.
echo [AVENA] No Python version is pinned. Existing Python is preferred.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run_windows.ps1"
set "STATUS=%ERRORLEVEL%"
if not "%STATUS%"=="0" (
  echo [AVENA] RUN failed with exit code %STATUS%
  pause
)
exit /b %STATUS%
