@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Avena Electrical - CONNECT CHATGPT
where powershell.exe >nul 2>&1
if errorlevel 1 (
 echo [AVENA] PowerShell is required.
 pause
 exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\connect_cloud.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" echo [AVENA] Cloud connection failed (exit %EXIT_CODE%).
pause
exit /b %EXIT_CODE%
