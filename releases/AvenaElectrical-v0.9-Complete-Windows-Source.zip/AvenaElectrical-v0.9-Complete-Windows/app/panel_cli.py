"""Offline expert panel reporting CLI and GUI helper, no COM or DWG writes."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from engineering.electrical.panel_pro import PanelPro, audit_panel_pro
from engineering.electrical.panel_pro_outputs import bom, bom_csv, feeder_schedule_csv, panel_sld_drafts


def reports(spec_file: Path, output_dir: Path) -> dict:
    spec = PanelPro.model_validate_json(spec_file.read_text(encoding="utf-8-sig"))
    output_dir.mkdir(parents=True, exist_ok=True)
    report = audit_panel_pro(spec)
    files = {
        "panel_audit.json": json.dumps(report, ensure_ascii=False, indent=2),
        "panel_bom.json": json.dumps(bom(spec), ensure_ascii=False, indent=2),
        "panel_bom.csv": bom_csv(spec),
        "panel_feeder_schedule.csv": feeder_schedule_csv(spec),
        "panel_sld_previews.json": json.dumps(panel_sld_drafts(spec), ensure_ascii=False, indent=2),
    }
    for name, content in files.items():
        (output_dir / name).write_text(content, encoding="utf-8-sig" if name.endswith(".csv") else "utf-8")
    return {"panel": spec.panel_id, "status": report["status"], "findings": report["counts"],
            "output_dir": str(output_dir), "files": list(files)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Avena Electrical Panel Pro — read-only preflight")
    parser.add_argument("spec", type=Path, help="PanelPro JSON file")
    parser.add_argument("--out", type=Path, default=Path.cwd() / "panel-reports")
    a = parser.parse_args()
    try:
        result = reports(a.spec, a.out)
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
