"""Avena Electrical Control Center for AutoCAD MCP Pro."""
__version__ = "0.9.0"
