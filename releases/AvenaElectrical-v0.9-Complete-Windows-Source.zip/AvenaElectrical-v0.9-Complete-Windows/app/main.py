"""Avena Electrical launcher executable entry point."""
from __future__ import annotations
import sys


def main():
    if "--mcp-server" in sys.argv:
        from app.runner import run_mcp_server
        run_mcp_server()
    elif "--cloud-agent" in sys.argv:
        from app.cloud_agent import main as cloud_main
        cloud_main()
    elif "--probe-json" in sys.argv:
        import json
        from app.com_probe import probe_all
        print(json.dumps(probe_all(), ensure_ascii=False, indent=2))
    else:
        from app.font_loader import register_local_font
        register_local_font()
        from app.gui import run_gui
        run_gui()


if __name__ == "__main__":
    main()
