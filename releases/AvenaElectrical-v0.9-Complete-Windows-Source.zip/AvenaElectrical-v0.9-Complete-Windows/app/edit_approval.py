"""Constrained edit contract for existing DWG entities. No delete/save/commands.

Only edits explicitly approved in a separate on-screen Windows dialog are permitted.
Handles must come from entity_list; never resolve arbitrary filesystem paths.
"""
from __future__ import annotations
import math
import re

TOOLS = {
    'move': 'entity_move',
    'text': 'entity_edit_text',
    'properties': 'entity_set_properties',
}
REQUIRED = {
    'move': {'handle','dx','dy'},
    'text': {'handle','text'},
    'properties': {'handle','layer'},
}
OPTIONAL = {
    'move': {'dz'},
    'text': {'height','rotation'},
    'properties': {'color'},
}

def validate_edits(operations):
    if not isinstance(operations,list) or not 1<=len(operations)<=8:
        raise ValueError('Provide 1 to 8 edit operations per approval')
    clean=[]
    for item in operations:
        if not isinstance(item,dict) or set(item)!={'type','args'}:
            raise ValueError('Edit must contain type and args')
        kind=item['type']
        if kind not in TOOLS:raise ValueError('Forbidden edit operation')
        a=item['args']
        if not isinstance(a,dict) or not REQUIRED[kind].issubset(a) or not set(a).issubset(REQUIRED[kind]|OPTIONAL[kind]):
            raise ValueError('Unsupported edit arguments')
        if not isinstance(a['handle'],str) or not re.fullmatch(r'[A-Fa-f0-9]{1,16}',a['handle']) or int(a['handle'],16)==0:
            raise ValueError('Invalid AutoCAD handle')
        for k,v in a.items():
            if k in ('dx','dy','dz','height','rotation') and (type(v) not in (int,float) or not math.isfinite(v) or abs(v)>100000):
                raise ValueError('Invalid numeric value')
        if kind=='text':
            if not isinstance(a['text'],str) or not 1<=len(a['text'])<=256 or any(c in a['text'] for c in '\r\n\x00'):
                raise ValueError('Invalid label')
            if a.get('height',1)<=0:raise ValueError('Invalid text height')
        if kind=='properties':
            if not isinstance(a['layer'],str) or not re.fullmatch(r'[\w.$ -]{1,80}',a['layer']):
                raise ValueError('Invalid layer')
            if 'color' in a and (type(a['color']) is not int or not 0<=a['color']<=256):
                raise ValueError('Invalid ACI color')
        clean.append({'type':kind,'args':dict(a)})
    return clean
