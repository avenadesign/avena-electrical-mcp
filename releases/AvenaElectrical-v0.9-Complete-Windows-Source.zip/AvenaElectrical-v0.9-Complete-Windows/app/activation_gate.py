"""Mandatory first-run license screen; code activation + persistent Windows DPAPI credential.

The user enters a 20-character code once.  No code or plaintext device token is
written to disk; Windows DPAPI protects the token in cloud_agent.
"""
from __future__ import annotations

import threading
import tkinter as tk
import urllib.error
import webbrowser
from tkinter import messagebox

from app.cloud_agent import activated_token
from app.gui import COL

COLORS = {"bg":COL["bg"],"surface":COL["panel"],"border":COL["line"],
          "text":COL["text"],"muted":COL["muted"],"accent":COL["accent"],"error":COL["red"]}


def format_code(raw: str) -> str:
    """Normalize accidental spaces/hyphens without reducing code entropy."""
    normalized = "".join(ch for ch in raw.strip().upper() if ch not in " -\t\n")
    if len(normalized) != 20 or not normalized.isascii() or not normalized.isalnum():
        raise ValueError("کد باید ۲۰ کاراکتر انگلیسی یا عدد باشد.")
    return "-".join(normalized[i:i+4] for i in range(0, 20, 4))


class ActivationGate:
    def __init__(self, root: tk.Tk, *, font: str, on_success):
        self.root = root
        self.on_success = on_success
        self.busy = False
        self.window = tk.Toplevel(root)
        self.window.title("فعال‌سازی | Avena Electrical")
        self.window.configure(bg=COLORS["bg"])
        self.window.geometry("530x485")
        self.window.minsize(440,440)
        self.window.transient(root)
        self.window.protocol("WM_DELETE_WINDOW", self.quit)
        self.window.grab_set()
        self.window.focus_force()

        pad = tk.Frame(self.window, bg=COLORS["bg"], padx=32, pady=25)
        pad.pack(fill="both", expand=True)
        self.title = tk.Label(pad, text="آونا الکتریکال", bg=COLORS["bg"],
            fg=COLORS["text"], font=(font,22,"bold"))
        self.title.pack(anchor="e")
        tk.Label(pad,text="Avena Electrical  ·  فعال‌سازی دستگاه", bg=COLORS["bg"],
            fg=COLORS["accent"],font=("Segoe UI",10)).pack(anchor="e",pady=(5,17))
        panel = tk.Frame(pad,bg=COLORS["surface"],highlightbackground=COLORS["border"],
            highlightthickness=1,padx=22,pady=19)
        panel.pack(fill="both",expand=True)
        tk.Label(panel,text="کد لایسنس را وارد کن",bg=COLORS["surface"],
            fg=COLORS["text"],font=(font,15,"bold")).pack(anchor="e",pady=(0,10))
        tk.Label(panel,text="شماره موبایلت را در سایت ثبت کن، کد اتصال را بگیر و همین‌جا وارد کن.\nپس از اولین فعال‌سازی، اتصال خودکار است و کد دوباره خواسته نمی‌شود.",
            justify="right",anchor="e",wraplength=385,bg=COLORS["surface"],fg=COLORS["muted"],
            font=(font,10)).pack(fill="x",pady=(0,15))
        self.code=tk.StringVar()
        self.entry=tk.Entry(panel,textvariable=self.code,relief="flat",bd=0,
            bg=COLORS["bg"],fg=COLORS["text"],insertbackground=COLORS["accent"],
            justify="center",font=("Consolas",15))
        self.entry.pack(fill="x",ipady=12)
        self.entry.bind("<Return>",lambda e:self.activate())
        self.entry.focus_set()
        self.info=tk.Label(panel,text="کد ۲۰ کاراکتری، بدون تاریخ انقضا تا لغو دستی",
            bg=COLORS["surface"],fg=COLORS["muted"],font=(font,9))
        self.info.pack(anchor="e",pady=(10,9))
        self.activate_btn=tk.Button(panel,text="فعال‌سازی و ورود",command=self.activate,
            bg=COLORS["accent"],fg="#ffffff",activebackground="#4deadd",
            relief="flat",bd=0,padx=15,pady=10,cursor="hand2",font=(font,11,"bold"))
        self.activate_btn.pack(fill="x",pady=(0,10))
        tk.Button(panel,text="دریافت کد از سایت آونا",command=lambda:webbrowser.open("https://elc.avenaai.ir/connect"),
            bg=COLORS["surface"],fg=COLORS["accent"],activebackground=COLORS["surface"],
            relief="flat",bd=0,cursor="hand2",font=(font,10)).pack(anchor="e")
        tk.Label(pad,text="بدون OTP و اشتراک در نسخه آزمایشی  •  اتصال امن با HTTPS",
            bg=COLORS["bg"],fg=COLORS["muted"],font=(font,9)).pack(anchor="e",pady=(12,0))
        # Existing credentials get validated without asking user for a license again.
        self.set_busy(True,"در حال بررسی فعال‌سازی ذخیره‌شده ...")
        threading.Thread(target=self.check_saved,daemon=True).start()

    def set_busy(self, flag: bool, message: str):
        self.busy=flag
        self.activate_btn.configure(state="disabled" if flag else "normal")
        self.info.configure(text=message,fg=COLORS["muted"] if flag else COLORS["error"])

    def check_saved(self):
        try:
            from app.cloud_agent import has_saved_activation
            if not has_saved_activation():
                self.root.after(0, lambda:self.set_busy(False,"برای شروع یک‌بار کد اتصال را وارد کن."))
                return
            activated_token()  # validates with /agent/status
            self.root.after(0,self.finish)
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                msg="مجوز دستگاه لغو شده؛ کد جدید وارد کن."
            else:
                msg=f"خطای سرور {exc.code}؛ اتصال اینترنت را بررسی کن و دوباره تلاش کن."
            self.root.after(0,lambda:self.set_busy(False,msg))
        except Exception as exc:
            msg=f"سرور فعال‌سازی در دسترس نیست: {type(exc).__name__}"
            self.root.after(0,lambda:self.set_busy(False,msg))

    def activate(self):
        if self.busy:return
        try:code=format_code(self.code.get())
        except ValueError as exc:
            messagebox.showerror("کد لایسنس",str(exc),parent=self.window)
            return
        self.set_busy(True,"در حال ثبت کد روی سرور آونا ...")
        def worker():
            try:
                activated_token(code)
                self.root.after(0,self.finish)
            except urllib.error.HTTPError as exc:
                failures={401:"کد نامعتبر یا لغوشده است.",409:"این لایسنس قبلاً روی دستگاه دیگری فعال شده.",429:"تلاش زیاد؛ بعداً امتحان کن."}
                message=failures.get(exc.code,f"خطای سرور: {exc.code}")
                self.root.after(0,lambda:self.set_busy(False,message))
            except Exception as exc:
                msg=f"ارتباط برقرار نشد: {type(exc).__name__} — {str(exc)[:120]}"
                self.root.after(0,lambda:self.set_busy(False,msg))
        threading.Thread(target=worker,daemon=True).start()

    def finish(self):
        self.code.set("")
        self.window.grab_release()
        self.window.destroy()
        self.on_success()

    def quit(self):
        # A fresh unlicensed machine must not access the control center.
        self.root.destroy()
