"""Bilingual Persian-first desktop control center (Tkinter/ttk, no bundled fonts)."""
from __future__ import annotations

import json
import socket
import secrets
import subprocess
import sys
import tkinter as tk
import webbrowser
import os
import threading
import urllib.request
from pathlib import Path
from tkinter import ttk, filedialog, messagebox, simpledialog, font as tkfont
from datetime import datetime

from app import __version__
from app.com_probe import CAD_PROGIDS, probe
from app.runner import DEFAULT_PORT, mcp_environment

BRAND = "Avena Electrical"
DOMAIN = "https://elc.avenaai.ir"
WEBSITE = "https://avenadesign.net"
PHONE = "09120720182"
SUPPORT = "tel:+989120720182"
THEMES = {
    "dark": {"bg":"#0e1625","panel":"#18243a","line":"#33445c","text":"#eef4ff",
             "muted":"#a2b1c7","accent":"#43d7c5","blue":"#629ffc","red":"#ff8392","input":"#101c2d","button":"#22324b"},
    "light":{"bg":"#f4f7fb","panel":"#ffffff","line":"#dde5ef","text":"#182638",
             "muted":"#5f7289","accent":"#067e78","blue":"#326bd4","red":"#bd3350","input":"#eff4fa","button":"#edf2f9"},
}
COL = dict(THEMES["dark"])

def load_theme():
    try:
        path=Path(os.getenv("LOCALAPPDATA") or Path.home())/"AvenaElectrical"/"preferences.json"
        theme=json.loads(path.read_text(encoding="utf-8")).get("theme")
        return theme if theme in THEMES else "dark"
    except (OSError,ValueError,TypeError):return "dark"

def save_theme(theme):
    path=Path(os.getenv("LOCALAPPDATA") or Path.home())/"AvenaElectrical"/"preferences.json"
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({"theme":theme}),encoding="utf-8")


def choose_font(root: tk.Tk) -> str:
    available = set(tkfont.families(root))
    # Never bundle a proprietary typeface; use a locally installed licensed family.
    for name in ("Digikala New", "DigikalaNew", "IRANYekanX", "IRANYekan", "Yekan Bakh", "YekanBakh", "Vazirmatn", "Tahoma", "Segoe UI"):
        if name in available:
            return name
    return "TkDefaultFont"


class ControlCenter:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{BRAND}  |  Avena Design")
        self.root.geometry("1120x800")
        self.root.minsize(700, 500)
        self.theme=load_theme()
        COL.update(THEMES[self.theme])
        self.root.configure(bg=COL["bg"])
        self.font = choose_font(root)
        self.release = tk.StringVar(value="2027")
        self.allowed = tk.StringVar(value=str(Path.home() / "Documents" / "AutoCAD"))
        self.status = tk.StringVar(value="اتصال هنوز بررسی نشده است")
        self.token = secrets.token_urlsafe(36)
        self.proc: subprocess.Popen | None = None
        self.cloud_proc: subprocess.Popen | None = None
        self.cloud_secret = None
        self.draw_enabled = tk.BooleanVar(value=True)
        self._licensed = False
        self._cloud_manual_stop = False
        self._last_auto_message = None
        self._ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(350, self._show_license_gate)

    def _show_license_gate(self):
        from app.activation_gate import ActivationGate
        self.license_gate = ActivationGate(self.root,font=self.font,on_success=self._license_accepted)

    def _license_accepted(self):
        self._licensed = True
        self._cloud_manual_stop = False
        self.log("Avena device licensed; preparing automatic connection")
        self.root.after(100, self.check)
        self.root.after(900, self._auto_connect)

    def _auto_connect(self):
        """Attach only to an already-running CAD and safe allowed DWG.

        A connected license is not a license to silently open, modify or save DWGs.
        On CAD startup later, this timer connects automatically without another code.
        """
        if not self._licensed or self._cloud_manual_stop:
            return
        if self.proc and self.proc.poll() is None:
            if not self.cloud_proc or self.cloud_proc.poll() is not None:
                self._launch_cloud()
            self.root.after(15000,self._auto_connect)
            return
        detected = []
        for release in (self.release.get(), "2026" if self.release.get()=="2027" else "2027"):
            result = probe(release)
            if result.available:
                detected.append(result)
                break
        if detected:
            result=detected[0]
            if result.document_path:
                try:
                    drawing=Path(result.document_path).resolve(strict=False)
                    allowed=Path(self.allowed.get()).resolve(strict=True)
                    if drawing.is_relative_to(allowed):
                        self.release.set(result.release)
                        self.start()
                    else:
                        self._auto_notice("نقشه فعال خارج از پوشه مجاز است؛ اتصال خودکار منتظر نقشه مجاز می‌ماند.")
                except OSError:
                    self._auto_notice("پوشه مجاز در دسترس نیست؛ مسیر را تنظیم کن.")
            else:
                self._auto_notice("اتوکد باز است؛ برای اتصال خودکار یک DWG ذخیره‌شده باز کن.")
        else:
            self._auto_notice("لایسنس فعال است؛ منتظر اجرای AutoCAD 2026 یا 2027 ...")
        self.root.after(15000,self._auto_connect)

    def _auto_notice(self,text):
        if self._last_auto_message!=text:
            self._last_auto_message=text
            self.log(text)
        self.cloud_status_label.configure(text=text,fg=COL["muted"])

    def text(self, parent, value, size=11, color="text", bold=False, **kwargs):
        return tk.Label(parent,text=value,bg=kwargs.pop("bg",parent.cget("bg")),
            fg=COL.get(color,color),font=(self.font,size,"bold" if bold else "normal"),
            anchor="e",justify="right",**kwargs)

    def button(self, parent, caption, command, accent=False):
        return tk.Button(parent,text=caption,command=command,
            bg=COL["accent"] if accent else COL["button"],
            fg="#ffffff" if accent else COL["text"],
            activebackground=COL["blue"],activeforeground="#ffffff",
            relief="flat",bd=0,cursor="hand2",padx=17,pady=11,
            font=(self.font,10,"bold"),highlightthickness=0)

    def panel(self, parent):
        return tk.Frame(parent,bg=COL["panel"],highlightbackground=COL["line"],
                        highlightthickness=1,padx=21,pady=17)

    def _switch_theme(self):
        next_theme="light" if self.theme=="dark" else "dark"
        saved_log=self.logs.get("1.0","end-1c") if hasattr(self,"logs") else ""
        previous_state=self.state_label.cget("text") if hasattr(self,"state_label") else ""
        previous_cloud=self.cloud_status_label.cget("text") if hasattr(self,"cloud_status_label") else ""
        self.theme=next_theme
        COL.update(THEMES[next_theme])
        try:save_theme(next_theme)
        except OSError:pass
        for widget in self.root.winfo_children():widget.destroy()
        self.root.configure(bg=COL["bg"])
        self._ui()
        if saved_log:
            self.logs.configure(state="normal")
            self.logs.insert("end",saved_log+"\n")
            self.logs.configure(state="disabled")
            self.logs.see("end")
        self.state_label.configure(text=previous_state)
        self.cloud_status_label.configure(text=previous_cloud)

    def _ui(self):
        style=ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Avena.TRadiobutton",background=COL["panel"],foreground=COL["text"],
                        font=(self.font,11),padding=4)
        style.map("Avena.TRadiobutton",background=[("active",COL["panel"])],foreground=[("active",COL["text"])])
        style.configure("Avena.Vertical.TScrollbar",background=COL["line"],troughcolor=COL["bg"],borderwidth=0)

        # Fixed, compact navigation bar. No gradient, large decorative elements or clutter.
        header=tk.Frame(self.root,bg=COL["panel"],padx=24,pady=17,
                        highlightbackground=COL["line"],highlightthickness=1)
        header.pack(fill="x")
        left=tk.Frame(header,bg=COL["panel"]);left.pack(side="left",anchor="center")
        self.button(left,"☀  روشن" if self.theme=="dark" else "☾  تیره",self._switch_theme).pack(side="left",padx=(0,8))
        self.button(left,"وب‌سایت",lambda:webbrowser.open(DOMAIN)).pack(side="left")
        right=tk.Frame(header,bg=COL["panel"]);right.pack(side="right",fill="x")
        self.text(right,"آونا الکتریکال",20,"text",True).pack(anchor="e")
        self.text(right,f"AVENA ELECTRICAL  /  {__version__}   •   اتصال ایمن به AutoCAD",9,"muted").pack(anchor="e",pady=(3,0))

        surface=tk.Frame(self.root,bg=COL["bg"]);surface.pack(fill="both",expand=True)
        canvas=tk.Canvas(surface,bg=COL["bg"],highlightthickness=0,bd=0)
        scrollbar=ttk.Scrollbar(surface,orient="vertical",command=canvas.yview,style="Avena.Vertical.TScrollbar")
        scrollbar.pack(side="left",fill="y")
        canvas.pack(side="right",fill="both",expand=True)
        canvas.configure(yscrollcommand=scrollbar.set)
        content=tk.Frame(canvas,bg=COL["bg"],padx=24,pady=21)
        window=canvas.create_window((0,0),window=content,anchor="nw")
        content.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        self._canvas=canvas
        def wheel(event):
            if not canvas.winfo_exists():return
            widget=self.root.winfo_containing(event.x_root,event.y_root)
            if hasattr(self,"logs") and widget is self.logs:return
            if event.delta:canvas.yview_scroll(-3 if event.delta>0 else 3,"units")
            return "break"
        self.root.bind_all("<MouseWheel>",wheel)
        self.root.bind_all("<Button-4>",lambda e:canvas.yview_scroll(-3,"units"))
        self.root.bind_all("<Button-5>",lambda e:canvas.yview_scroll(3,"units"))

        main=tk.Frame(content,bg=COL["bg"])
        side=tk.Frame(content,bg=COL["bg"])
        self._layout_mode=None
        def layout(event=None):
            available=canvas.winfo_width()
            mode="stack" if available<850 else "columns"
            canvas.itemconfigure(window,width=available)
            if mode==self._layout_mode:return
            self._layout_mode=mode
            main.pack_forget();side.pack_forget()
            if mode=="stack":
                main.pack(side="top",fill="x",pady=(0,12))
                side.pack(side="top",fill="x")
            else:
                main.pack(side="right",fill="both",expand=True,padx=(9,0))
                side.pack(side="left",fill="both",expand=True,padx=(0,9))
        canvas.bind("<Configure>",layout)
        main.pack(side="right",fill="both",expand=True,padx=(9,0))
        side.pack(side="left",fill="both",expand=True,padx=(0,9))

        introduction=tk.Frame(main,bg=COL["bg"])
        introduction.pack(fill="x",pady=(0,14))
        self.text(introduction,"کنترل اتصال و ترسیم",16,"text",True).pack(anchor="e")
        self.text(introduction,"نقشه باز، پوشه مجاز، سرور MCP و ارتباط ChatGPT را از همین صفحه مدیریت کن.",10,"muted",wraplength=560).pack(anchor="e",pady=(5,0))

        p=self.panel(main);p.pack(fill="x",pady=(0,13))
        self.text(p,"۰۱   نرم‌افزار AutoCAD",13,"text",True).pack(anchor="e",pady=(0,7))
        self.text(p,"نسخه اجرای COM را انتخاب کن.",10,"muted").pack(anchor="e",pady=(0,8))
        for rel in ("2027","2026"):
            ttk.Radiobutton(p,text=f"AutoCAD / Electrical {rel}",variable=self.release,value=rel,
                            style="Avena.TRadiobutton",command=self.check).pack(anchor="e",pady=2)
        self.button(p,"بررسی AutoCAD COM",self.check).pack(anchor="e",pady=(11,0))

        paths=self.panel(main);paths.pack(fill="x",pady=(0,13))
        self.text(paths,"۰۲   پوشه مجاز DWG",13,"text",True).pack(anchor="e",pady=(0,9))
        path_entry=tk.Entry(paths,textvariable=self.allowed,bg=COL["input"],fg=COL["text"],
                            insertbackground=COL["accent"],relief="flat",font=("Segoe UI",10),bd=0)
        path_entry.pack(fill="x",ipady=9)
        self.button(paths,"انتخاب پوشه",self.choose_path).pack(anchor="e",pady=(10,0))
        self.text(paths,"خواندن و ترسیم فقط برای فایل‌های DWG داخل این پوشه مجاز است.",9,"muted",wraplength=540).pack(anchor="e",pady=(8,0))

        p3=self.panel(main);p3.pack(fill="x",pady=(0,13))
        self.text(p3,"۰۳   اتصال MCP و ChatGPT",13,"text",True).pack(anchor="e",pady=(0,8))
        self.text(p3,f"127.0.0.1:{DEFAULT_PORT}  /  https://elc.avenaai.ir/mcp",10,"accent").pack(anchor="e")
        buttons=tk.Frame(p3,bg=COL["panel"]);buttons.pack(anchor="e",pady=(12,4))
        self.button(buttons,"توقف",self.stop).pack(side="left",padx=(0,8))
        self.button(buttons,"اجرای سرور محلی",self.start,True).pack(side="left")
        remote=tk.Frame(p3,bg=COL["panel"]);remote.pack(anchor="e",pady=(6,8))
        self.button(remote,"قطع ارتباط",self.stop_cloud).pack(side="left",padx=(0,8))
        self.button(remote,"اتصال به ChatGPT",self.start_cloud,True).pack(side="left")
        self.text(p3,"لایسنس یک‌بار فعال می‌شود؛ ارتباط خروجی از ویندوز برقرار می‌ماند.",9,"muted",wraplength=535).pack(anchor="e")
        self.cloud_status_label=self.text(p3,"اتصال ابری برقرار نیست",10,"muted",True)
        self.cloud_status_label.pack(anchor="e",pady=(10,0))
        chk=tk.Checkbutton(p3,text="اجازه ترسیم پس از تأیید روی ویندوز",variable=self.draw_enabled,
             bg=COL["panel"],fg=COL["text"],activebackground=COL["panel"],
             activeforeground=COL["text"],selectcolor=COL["input"],font=(self.font,10),anchor="e")
        chk.pack(anchor="e",pady=(10,0))
        self.text(p3,"ترسیم و ویرایشِ متن، لایه و جابه‌جایی با تأیید تو؛ بدون حذف یا Save خودکار.",9,"muted",wraplength=530).pack(anchor="e",pady=(7,0))

        action_bar=self.panel(side);action_bar.pack(fill="x",pady=(0,13))
        self.text(action_bar,"وضعیت سیستم",13,"text",True).pack(anchor="e",pady=(0,7))
        self.state_label=self.text(action_bar,"اتوکد بررسی نشده است",10,"accent",True,wraplength=390)
        self.state_label.pack(fill="x",pady=(0,10))
        self.button(action_bar,"بررسی کامل اتصال",self.diagnose).pack(fill="x",pady=(2,7))
        self.button(action_bar,"کپی تنظیم MCP محلی",self.copy_mcp).pack(fill="x")
        self.text(action_bar,"اتصال ChatGPT و اجرای COM دو مرحله جدا هستند؛ نتیجه هرکدام گزارش می‌شود.",9,"muted",wraplength=390).pack(anchor="e",pady=(8,0))

        report=self.panel(side);report.pack(fill="x",pady=(0,13))
        self.text(report,"طراحی و کنترل تابلو برق",13,"text",True).pack(anchor="e",pady=(0,7))
        self.text(report,"گزارش مدارها، BOM، فیدرها و پیش‌طرح SLD",10,"muted",wraplength=390).pack(anchor="e",pady=(0,10))
        self.button(report,"تحلیل تابلو از فایل JSON",self.analyze_panel,True).pack(fill="x")
        self.button(report,"دریافت کد اتصال از سایت",lambda:webbrowser.open(DOMAIN+"/connect")).pack(fill="x",pady=(8,0))

        logs_card=self.panel(side);logs_card.pack(fill="both",expand=True)
        tk.Frame(logs_card,bg=COL["panel"]).pack(fill="x")
        self.text(logs_card,"گزارش رویدادها",13,"text",True).pack(anchor="e",pady=(0,10))
        self.logs=tk.Text(logs_card,bg=COL["input"],fg=COL["muted"],insertbackground=COL["accent"],
                          relief="flat",wrap="word",font=("Consolas",9),height=16,padx=12,pady=12)
        self.logs.pack(fill="both",expand=True)
        self.logs.configure(state="disabled")
        self.button(logs_card,"ذخیره گزارش",self.save_log).pack(anchor="w",pady=(10,0))

        footer=tk.Frame(self.root,bg=COL["bg"],padx=25,pady=10)
        footer.pack(fill="x")
        tk.Frame(footer,bg=COL["line"],height=1).pack(fill="x",pady=(0,10))
        row=tk.Frame(footer,bg=COL["bg"]);row.pack(fill="x")
        self.text(row,"Avena Design   ·   © 2026",9,"muted").pack(side="left")
        self.text(row,"پشتیبانی  ۰۹۱۲ ۰۷۲ ۰۱۸۲",9,"accent",True).pack(side="right")

    def diagnose(self):
        """Non-destructive, user-visible diagnostic. All secrets redacted."""
        report=[]
        status=probe(self.release.get())
        report.append("AutoCAD COM: "+("شناخته شد" if status.available else (status.error or "در دسترس نیست")))
        try:
            with socket.create_connection(("127.0.0.1",DEFAULT_PORT),timeout=1.5):
                report.append("Local MCP: TCP ready")
        except OSError:report.append("Local MCP: stopped or unavailable")
        def cloud_status():
            try:
                from app.cloud_agent import _read_state,_load_token,cloud_request
                token=_load_token(_read_state())
                if not token:return "Cloud pairing: license not activated"
                state=cloud_request("GET","/agent/status",token=token,timeout=9)
                return "Cloud agent: "+("connected" if state.get("online") else "paired but not polling")
            except Exception as exc:
                return "Cloud status: "+type(exc).__name__
        def worker():
            detail="\n".join(report+[cloud_status()])
            self.root.after(0,lambda:self._show_diagnostic(detail))
        threading.Thread(target=worker,daemon=True).start()

    def _show_diagnostic(self,detail):
        self.log("Connection diagnostic: "+detail.replace("\n"," | "))
        messagebox.showinfo("Avena Electrical — Diagnostics",detail,parent=self.root)

    def log(self, msg):
        self.logs.configure(state="normal")
        self.logs.insert("end",f"[{datetime.now():%H:%M:%S}] {msg}\n")
        self.logs.see("end")
        self.logs.configure(state="disabled")

    def check(self):
        result=probe(self.release.get())
        self.state_label.configure(text=(
            f"متصل به AutoCAD {result.release} | سند: {result.document_name or 'بدون سند'}" 
            if result.available else f"اتصال برقرار نیست — {result.release}"
        ),fg=COL["accent"] if result.available else COL["red"])
        self.log(json.dumps(result.asdict(),ensure_ascii=False))

    def analyze_panel(self):
        """Generate strictly read-only checks, BOM and SLD plans; never edits CAD."""
        from app.panel_cli import reports
        path=filedialog.askopenfilename(title="مشخصات تابلو PanelPro (JSON)", filetypes=[("JSON", "*.json")])
        if not path:
            return
        dest=filedialog.askdirectory(title="محل ذخیره گزارش تابلو")
        if not dest:
            return
        try:
            result=reports(Path(path), Path(dest))
        except Exception as exc:
            self.log(f"Panel validation failed: {exc}")
            messagebox.showerror("خطا در مشخصات تابلو",str(exc))
            return
        self.log(json.dumps(result,ensure_ascii=False))
        messagebox.showinfo("گزارش تابلو", f"فایل‌های گزارش و پیش‌طرح ذخیره شدند.\n{dest}\nاین خروجی تأییدیه مهندسی نیست.")

    def choose_path(self):
        path=filedialog.askdirectory(title="پوشه مجاز نقشه‌ها")
        if path:self.allowed.set(path)

    def start(self):
        if self.proc and self.proc.poll() is None:
            self.log("MCP is already running")
            return
        diagnosis=probe(self.release.get())
        if not diagnosis.available:
            messagebox.showwarning("اتصال COM", "ابتدا AutoCAD نسخه انتخاب‌شده را اجرا و اتصال را بررسی کنید.")
            return
        # A user can inspect any open drawing, but starting a mutable MCP
        # on an unrelated drawing is unsafe; only start in the allowed folder.
        try:
            candidate = Path(diagnosis.document_path or "").resolve(strict=False)
            allowed_root = Path(self.allowed.get()).resolve(strict=True)
            if not diagnosis.document_path or not candidate.is_relative_to(allowed_root):
                messagebox.showwarning("محدوده نقشه", "برای اجرای MCP یک Drawing ذخیره‌شده در پوشه مجاز باز کنید.")
                return
        except OSError:
            messagebox.showwarning("محدوده نقشه", "پوشه مجاز وجود ندارد.")
            return
        try:
            env=mcp_environment(self.release.get(),self.allowed.get(),self.token)
        except (ValueError,OSError) as exc:
            messagebox.showerror("مسیر مجاز",str(exc));return
        cmd=[sys.executable,"--mcp-server"] if getattr(sys,"frozen",False) else [sys.executable,"-m","app.main","--mcp-server"]
        flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
        try:
            self.proc=subprocess.Popen(cmd,env=env,creationflags=flags,
                        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except OSError as exc:
            messagebox.showerror("MCP",str(exc));return
        self.log(f"Local MCP process launched; checking TCP 127.0.0.1:{DEFAULT_PORT} shortly")
        self.root.after(1800, self._check_started)
        self.log("Token is retained in memory only. Direct ChatGPT Cloud access is NOT enabled.")

    def start_cloud(self):
        self._cloud_manual_stop = False
        from app.cloud_agent import has_saved_activation, activated_token
        if self.cloud_proc and self.cloud_proc.poll() is None:
            self.log("Cloud agent already active")
            return
        if not self.proc or self.proc.poll() is not None:
            messagebox.showwarning("MCP محلی", "ابتدا MCP محلی را اجرا کن؛ سپس اتصال ابری را فعال کن.")
            return
        code=None
        if not has_saved_activation():
            code=simpledialog.askstring("اتصال به ChatGPT", "کد ۲۰ کاراکتری دریافتی از elc.avenaai.ir/connect را وارد کن:",parent=self.root)
            if not code:
                return
            if len(code.replace("-", "").replace(" ", ""))!=20:
                messagebox.showerror("کد اتصال", "کد باید ۲۰ حرف یا عدد باشد. از صفحه فعال‌سازی کپی کن.")
                return
        self.cloud_status_label.configure(text="در حال بررسی و فعال‌سازی دستگاه...",fg=COL["accent"])
        def work():
            try:
                activated_token(code)
                self.root.after(0,self._launch_cloud)
            except urllib.error.HTTPError as exc:
                messages={401:"کد اتصال اشتباه است یا لغو شده.",409:"این کد قبلاً روی رایانه دیگری فعال شده است.",429:"تعداد تلاش زیاد است؛ بعداً دوباره امتحان کن."}
                msg=messages.get(exc.code,f"خطای پاسخ سرور: {exc.code}")
                self.root.after(0,lambda:messagebox.showerror("اتصال آونا",msg))
                self.root.after(0,lambda:self.cloud_status_label.configure(text="فعال‌سازی انجام نشد",fg=COL["red"]))
            except (OSError, ValueError, RuntimeError) as exc:
                msg=str(exc)[:250]
                self.root.after(0,lambda:messagebox.showerror("اتصال آونا",msg))
                self.root.after(0,lambda:self.cloud_status_label.configure(text="فعال‌سازی انجام نشد",fg=COL["red"]))
        threading.Thread(target=work,daemon=True).start()

    def _launch_cloud(self):
        if self.cloud_proc and self.cloud_proc.poll() is None:
            return
        environment=dict(os.environ)
        environment["AVENA_ALLOWED_PATHS"] = self.allowed.get()
        environment["AVENA_AUTOCAD_RELEASE"] = self.release.get()
        environment["AVENA_DRAW_ENABLED"] = "1" if self.draw_enabled.get() else "0"
        environment["AVENA_LOCAL_MCP_TOKEN"]=self.token
        environment.pop("AVENA_ACTIVATION_CODE",None)
        cmd=([sys.executable,"--cloud-agent"] if getattr(sys,"frozen",False)
             else [sys.executable,"-m","app.main","--cloud-agent"])
        try:
            self.cloud_proc=subprocess.Popen(cmd,env=environment,
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except OSError as exc:
            messagebox.showerror("ChatGPT",str(exc))
            return
        self.cloud_status_label.configure(text="در حال اتصال به سرور آونا...",fg=COL["accent"])
        self.log("Cloud device activated; agent started using per-user Windows protected credential")
        self.root.after(2200,self.check_cloud)

    def check_cloud(self):
        if not self.cloud_proc or self.cloud_proc.poll() is not None:
            self.cloud_status_label.configure(text="عامل ابری متوقف شده",fg=COL["red"])
            return
        def check():
            try:
                from app.cloud_agent import _load_token, _read_state, cloud_request
                token=_load_token(_read_state())
                if not token:
                    raise RuntimeError("No paired device token")
                state=cloud_request("GET","/agent/status",token=token,timeout=7)
                online=bool(state.get("online"))
                self.root.after(0,lambda:self.cloud_status_label.configure(
                    text="متصل به سرور آونا" if online else "دستگاه فعال است؛ منتظر اتصال عامل ویندوز",
                    fg=COL["accent"] if online else COL["muted"]))
            except (OSError,ValueError,RuntimeError):
                self.root.after(0,lambda:self.cloud_status_label.configure(text="اتصال ابری پاسخ نمی‌دهد",fg=COL["red"]))
        threading.Thread(target=check,daemon=True).start()

    def stop_cloud(self):
        self._cloud_manual_stop = True
        if self.cloud_proc and self.cloud_proc.poll() is None:
            self.cloud_proc.terminate()
            try:self.cloud_proc.wait(timeout=4)
            except subprocess.TimeoutExpired:self.cloud_proc.kill()
        self.cloud_proc=None
        self.cloud_secret=None
        if hasattr(self,"cloud_status_label"):
            self.cloud_status_label.configure(text="اتصال ابری برقرار نیست",fg=COL["muted"])

    def copy_mcp(self):
        # Clipboard is user-initiated; credentials are never stored to disk.
        details = json.dumps({
            "transport": "http", "url": f"http://127.0.0.1:{DEFAULT_PORT}/mcp",
            "headers": {"Authorization": f"Bearer {self.token}"}
        }, ensure_ascii=False, indent=2)
        self.root.clipboard_clear()
        self.root.clipboard_append(details)
        self.log("Private MCP connection information copied to clipboard; do not share token.")

    def _check_started(self):
        if self.proc is None:
            return
        if self.proc.poll() is not None:
            self.log(f"MCP failed or exited, code {self.proc.returncode}; check process logs")
            self.proc = None
            return
        try:
            with socket.create_connection(("127.0.0.1", DEFAULT_PORT), timeout=1):
                self.log("Local MCP TCP listener is responding (not an end-to-end protocol test)")
        except OSError:
            self.log("MCP process running, but TCP port not ready; inspect logs")

    def stop(self):
        self.stop_cloud()
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:self.proc.wait(timeout=4)
            except subprocess.TimeoutExpired:self.proc.kill()
            self.log("Local MCP process stopped")
        self.proc=None

    def save_log(self):
        path=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text","*.txt")])
        if path:
            Path(path).write_text(self.logs.get("1.0","end"),encoding="utf-8")

    def close(self):
        self.stop()
        self.root.destroy()


def run_gui():
    root=tk.Tk()
    ControlCenter(root)
    root.mainloop()
