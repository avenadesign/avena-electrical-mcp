"""Local MCP runtime wrapper. Never starts AutoCAD, never exposes raw COM publicly."""
from __future__ import annotations
import os
import sys
from pathlib import Path

DEFAULT_PORT = 18327


def mcp_environment(release: str, allowed_directory: str, token: str) -> dict[str, str]:
    from app.com_probe import CAD_PROGIDS
    if release not in CAD_PROGIDS:
        raise ValueError("Unsupported release")
    try:
        root = Path(allowed_directory).expanduser().resolve(strict=True)
    except OSError as exc:
        raise ValueError("Allowed drawings directory does not exist") from exc
    if not root.is_dir():
        raise ValueError("Allowed drawings path must be an existing directory")
    if len(token) < 32:
        raise ValueError("MCP bearer token is too short")
    env = dict(os.environ)
    env.update({
        "AUTOCAD_MCP_BACKEND": "com", "CAD_PROGID": CAD_PROGIDS[release],
        "AVENA_ELECTRICAL_ENABLED": "true", "ALLOWED_PATHS": str(root),
        "MCP_AUTH_TOKEN": token, "ALLOW_REMOTE_HTTP": "false",
        "DANGEROUS_COMMANDS_ENABLED": "false", "AVENA_ATTACH_ONLY": "true", "TOOL_PROFILE": "full",
        "TOOL_PACKS": "all", "DISCOVERY_MODE": "off",
    })
    return env


def run_mcp_server() -> None:
    # The upstream server is bundled in the standalone executable by PyInstaller.
    # STDOUT is reserved for MCP only in stdio mode; this runs on loopback HTTP.
    import server
    sys.argv = ["autocad-mcp", "--transport", "http", "--host", "127.0.0.1", "--port", str(DEFAULT_PORT)]
    server.main()
