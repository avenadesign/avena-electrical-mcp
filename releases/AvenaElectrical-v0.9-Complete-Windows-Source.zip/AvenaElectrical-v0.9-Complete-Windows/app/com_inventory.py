"""Read-only semantic inventory of an AutoCAD document, using COM on the STA thread.

This is not an AutoCAD Electrical project database reader. Smart Electrical
components require dedicated native APIs; wire numbers are not inferred here.
"""
from __future__ import annotations

from app.com_probe import CAD_PROGIDS
import sys


def inventory(release: str, limit: int = 400) -> dict:
    if release not in CAD_PROGIDS:
        raise ValueError("unsupported AutoCAD release")
    if not isinstance(limit, int) or not 1 <= limit <= 2000:
        raise ValueError("limit must be 1..2000")
    if sys.platform != "win32":
        return {"ok": False, "reason": "COM only available on Windows", "release": release}
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    try:
        try:
            app = win32com.client.GetActiveObject(CAD_PROGIDS[release])
        except Exception as exc:
            return {"ok": False, "release": release, "reason": f"Not running: {exc}"}
        version = str(app.Version)
        expected = "25.1" if release == "2026" else "26."
        if not version.startswith(expected):
            return {"ok": False, "reason": "version_mismatch", "expected": release, "actual": version}
        doc = app.ActiveDocument
        model = doc.ModelSpace
        total = int(model.Count)
        items = []
        warnings = []
        # COM iteration of large ModelSpace can hang; strictly bound the read.
        for i in range(min(total, limit)):
            try:
                e = model.Item(i)
                name = str(e.ObjectName)
                row = {"handle": str(e.Handle), "object": name, "layer": str(e.Layer)}
                if name.endswith("BlockReference"):
                    row["name"] = str(e.Name)
                    try:
                        row["position"] = [round(float(n), 4) for n in e.InsertionPoint[:2]]
                    except Exception:
                        pass
                    try:
                        if bool(e.HasAttributes):
                            row["attributes"] = {
                                str(a.TagString): str(a.TextString)
                                for a in e.GetAttributes()
                            }
                    except Exception as exc:
                        warnings.append({"handle": row["handle"], "warning": f"attributes: {exc}"})
                items.append(row)
            except Exception as exc:
                warnings.append({"index": i, "warning": f"entity_read_failed: {exc}"})
        return {
            "ok": True, "release": release, "com_version": version,
            "document": {"name": str(doc.Name), "full_path": str(doc.FullName), "saved": bool(doc.Saved)},
            "modelspace_count": total, "inspected_count": len(items),
            "scan_incomplete": total > limit or len(items) != min(total, limit),
            "entities": items, "warnings": warnings,
            "native_electrical_certified": False,
            "note": "Block attribute inventory only. No ACADE electrical project semantic claims.",
        }
    except Exception as exc:
        return {"ok": False, "release": release, "reason": f"COM read failed: {exc}"}
    finally:
        pythoncom.CoUninitialize()
