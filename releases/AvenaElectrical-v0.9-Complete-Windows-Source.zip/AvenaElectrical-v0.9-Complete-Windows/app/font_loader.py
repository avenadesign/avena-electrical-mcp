"""Optional local user-owned Digikala New font; never bundled or redistributed.

Place your legitimately licensed `1.ttf` or `digikala.ttf` beside RUN.bat
(or the executable). On Windows it is registered PRIVATE to this process.
"""
from __future__ import annotations

import ctypes
import os
import sys
from pathlib import Path


def discover_local_font() -> Path | None:
    roots: list[Path] = [Path.cwd()]
    if getattr(sys, "frozen", False):
        roots.append(Path(sys.executable).resolve().parent)
    else:
        roots.append(Path(__file__).resolve().parents[1])
    for root in roots:
        for name in ("digikala.ttf", "1.ttf"):
            p = root / name
            if p.is_file():
                return p
    return None


def register_local_font() -> bool:
    if sys.platform != "win32":
        return False
    path = discover_local_font()
    if path is None:
        return False
    try:
        # FR_PRIVATE=0x10: no machine-wide installation or persistent registry changes.
        add = ctypes.windll.gdi32.AddFontResourceExW
        add.argtypes = [ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p]
        add.restype = ctypes.c_int
        return bool(add(str(path), 0x10, None))
    except (OSError, AttributeError):
        return False
