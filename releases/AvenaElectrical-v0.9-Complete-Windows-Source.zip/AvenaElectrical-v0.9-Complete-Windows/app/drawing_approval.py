"""Windows-side safe geometry plan and explicit human approval.

No arbitrary CAD commands, deletions, opens, saves or file-system modifications.
All geometry is in native DWG units. Windows app only; deliberately fails closed.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
import re
import tkinter as tk
from tkinter import ttk

TOOL_BY_TYPE = {
    "line": "entity_create_line",
    "rectangle": "entity_create_rectangle",
    "polyline": "entity_create_polyline",
    "circle": "entity_create_circle",
    "text": "entity_create_text",
    "block_ref": "entity_create_block_ref",
}
REQUIRED = {
    "line": {"x1", "y1", "x2", "y2"},
    "rectangle": {"x1", "y1", "x2", "y2"},
    "polyline": {"points"},
    "circle": {"cx", "cy", "radius"},
    "text": {"x", "y", "text"},
    "block_ref": {"x", "y", "name"},
}
OPTIONAL = {
    "line": {"layer", "color"},
    "rectangle": {"layer", "color"},
    "polyline": {"layer", "color", "closed"},
    "circle": {"layer", "color"},
    "text": {"layer", "color", "height", "rotation"},
    "block_ref": {"layer", "scale_x", "scale_y", "rotation"},
}

def _number(value):
    return type(value) in (int, float) and math.isfinite(value) and abs(value) <= 1000000

def validate_plan(operations):
    if not isinstance(operations, list) or not 1 <= len(operations) <= 25:
        raise ValueError("Between 1 and 25 additive CAD operations required")
    clean = []
    for i, raw in enumerate(operations, 1):
        if not isinstance(raw, dict) or set(raw) != {"type", "args"}:
            raise ValueError(f"Operation {i}: expected type and args")
        name = raw["type"]
        if name not in TOOL_BY_TYPE:
            raise ValueError(f"Operation {i}: operation not permitted")
        args = raw["args"]
        if not isinstance(args, dict) or not REQUIRED[name].issubset(args) or not set(args).issubset(REQUIRED[name] | OPTIONAL[name]):
            raise ValueError(f"Operation {i}: unsupported arguments")
        for key, value in args.items():
            if key in {"x1", "y1", "x2", "y2", "cx", "cy", "x", "y", "radius", "height", "rotation", "scale_x", "scale_y"}:
                if not _number(value):
                    raise ValueError(f"Operation {i}: invalid {key}")
            elif key == "color":
                if type(value) is not int or not 0 <= value <= 256:
                    raise ValueError(f"Operation {i}: invalid ACI color")
            elif key == "layer":
                if not isinstance(value, str) or re.fullmatch(r"[\w.$ -]{1,80}", value) is None:
                    raise ValueError(f"Operation {i}: invalid layer")
            elif key == "points":
                if not isinstance(value, list) or not 2 <= len(value) <= 100 or any(
                    not isinstance(pt, list) or len(pt) != 2 or not all(_number(q) for q in pt) for pt in value
                ):
                    raise ValueError(f"Operation {i}: invalid polyline points")
            elif key == "closed" and type(value) is not bool:
                raise ValueError(f"Operation {i}: closed must be boolean")
            elif key in ("text", "name"):
                if not isinstance(value, str) or not 1 <= len(value) <= (256 if key == "text" else 80) or any(c in value for c in "\x00\r\n"):
                    raise ValueError(f"Operation {i}: invalid text or block name")
                if key == "name" and value.startswith("*"):
                    raise ValueError(f"Operation {i}: layout blocks are forbidden")
        if name == "circle" and args["radius"] <= 0:
            raise ValueError(f"Operation {i}: circle radius must be positive")
        if name == "text" and args.get("height", 2.5) <= 0:
            raise ValueError(f"Operation {i}: text height must be positive")
        if name == "block_ref" and (args.get("scale_x",1) <= 0 or args.get("scale_y",1) <= 0):
            raise ValueError(f"Operation {i}: block scale must be positive")
        clean.append({"type": name, "args": dict(args)})
    return clean

def verify_active_drawing(release: str, allowed_path: str, expected_path: str | None = None):
    from app.com_probe import probe
    if release not in ("2026", "2027"):
        raise RuntimeError("No explicit AutoCAD release selected")
    if not allowed_path:
        raise RuntimeError("Allowed DWG directory was not configured")
    info = probe(release)
    if not info.available or not info.attached or not info.document_path:
        raise RuntimeError("AutoCAD/COM or active saved drawing is not available")
    root = Path(allowed_path).expanduser().resolve(strict=True)
    drawing = Path(info.document_path).expanduser().resolve(strict=True)
    if not drawing.is_file() or not drawing.is_relative_to(root) or drawing.suffix.lower() != ".dwg":
        raise RuntimeError("Active DWG is outside the allowed drawing folder")
    if expected_path is not None and os.path.normcase(str(drawing)) != os.path.normcase(str(expected_path)):
        raise RuntimeError("Active drawing changed during the drawing operation")
    return str(drawing)

def approve_on_windows(drawing_path: str, operations, *, timeout_ms=30000) -> bool:
    """Modal per-batch consent. If UI is inaccessible or times out, NEVER draw."""
    if os.name != "nt":
        return False
    root = tk.Tk()
    root.title("Avena Electrical — تأیید ترسیم در AutoCAD")
    root.configure(bg="#101d2f")
    root.geometry("630x480")
    root.minsize(490, 390)
    root.attributes("-topmost", True)
    decision = {"approved": False}
    def reject():
        root.destroy()
    def accept():
        decision["approved"] = True
        root.destroy()
    try:
        tk.Label(root, text="آیا ترسیم روی نقشه اتوکد اجرا شود؟", anchor="e", bg="#101d2f", fg="#eef8ff", font=("Tahoma", 14, "bold")) .pack(fill="x", padx=22, pady=(22, 9))
        tk.Label(root, text=drawing_path, bg="#101d2f", fg="#66dbcf", font=("Segoe UI", 10), wraplength=570).pack(fill="x", padx=22)
        tk.Label(root, text="فقط افزودن اجسام؛ بدون حذف، ذخیره یا اجرای دستور دلخواه. همه ابعاد بر اساس واحد نقشه فعلی است.", bg="#101d2f", fg="#bed1e3", wraplength=570, justify="right").pack(fill="x", padx=22, pady=10)
        body = tk.Text(root, bg="#192c42", fg="#eff8ff", relief="flat", wrap="word", height=14)
        body.pack(fill="both", expand=True, padx=22, pady=8)
        for index, op in enumerate(operations, 1):
            body.insert("end", f"{index}. {op['type']}  |  {op['args']}\n")
        body.configure(state="disabled")
        row = tk.Frame(root, bg="#101d2f"); row.pack(fill="x", padx=22, pady=(10, 20))
        tk.Button(row, text="رد درخواست", command=reject, bg="#33465b", fg="white", relief="flat", padx=24, pady=10).pack(side="left")
        tk.Button(row, text="تأیید و ترسیم", command=accept, bg="#30d3bb", fg="#072326", relief="flat", padx=24, pady=10).pack(side="right")
        root.protocol("WM_DELETE_WINDOW", reject)
        root.after(timeout_ms, reject)
        root.mainloop()
    finally:
        try:
            root.destroy()
        except tk.TclError:
            pass
    return decision["approved"]
