"""Avena Electrical Windows cloud connector v0.6.

Pairs with one long-lived activation code issued via https://elc.avenaai.ir/connect.
No OTP or subscriptions yet. Token stored using Windows DPAPI (per-user).
Outbound HTTPS; AutoCAD COM stays on Windows. Additive CAD drawing requires local consent.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes
import json
import os
from pathlib import Path
import secrets
import time
import urllib.error
import urllib.request

BASE = os.environ.get('AVENA_GATEWAY_URL', 'https://elc.avenaai.ir').rstrip('/')
LOCAL = 'http://127.0.0.1:18327/mcp'
ALLOWED = {'system_status', 'drawing_info', 'layer_list', 'block_list'}
DRAW_TASK = '__avena_draw_batch__'
EDIT_TASK = '__avena_edit_batch__'


def _storage_dir() -> Path:
    base = os.getenv('LOCALAPPDATA') or str(Path.home() / '.local' / 'share')
    return Path(base) / 'AvenaElectrical'


def _token_file() -> Path:
    return _storage_dir() / 'device.json'


def _dpapi(data: bytes, decrypt: bool) -> bytes:
    if os.name != 'nt':
        raise OSError('Device token persistence requires Windows DPAPI')
    class DATA_BLOB(ctypes.Structure):
        _fields_ = [('cbData', ctypes.wintypes.DWORD),
                    ('pbData', ctypes.POINTER(ctypes.c_ubyte))]
    raw = ctypes.create_string_buffer(data)
    src = DATA_BLOB(len(data), ctypes.cast(raw, ctypes.POINTER(ctypes.c_ubyte)))
    dst = DATA_BLOB()
    crypt32 = ctypes.WinDLL('crypt32', use_last_error=True)
    crypt32.CryptProtectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_wchar_p, ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.POINTER(ctypes.c_wchar_p), ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    crypt32.CryptProtectData.restype = ctypes.wintypes.BOOL
    crypt32.CryptUnprotectData.restype = ctypes.wintypes.BOOL
    local_free = ctypes.WinDLL('kernel32', use_last_error=True).LocalFree
    local_free.argtypes = [ctypes.c_void_p]
    local_free.restype = ctypes.c_void_p
    if decrypt:
        ok = crypt32.CryptUnprotectData(ctypes.byref(src), None, None, None, None, 0, ctypes.byref(dst))
    else:
        ok = crypt32.CryptProtectData(ctypes.byref(src), 'Avena Electrical Device', None, None, None, 0x01, ctypes.byref(dst))
    if not ok:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(dst.pbData, dst.cbData)
    finally:
        local_free(ctypes.cast(dst.pbData, ctypes.c_void_p))


def _read_state() -> dict:
    try:
        item = json.loads(_token_file().read_text(encoding='utf-8'))
        if isinstance(item, dict) and isinstance(item.get('device_id'), str):
            return item
    except (OSError, json.JSONDecodeError, ValueError):
        pass
    return {'device_id': secrets.token_hex(16)}


def _save_state(state):
    if os.name != 'nt':
        raise OSError('Saving device credentials is supported only on Windows')
    destination = _token_file()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')


def _load_token(state):
    encoded = state.get('encrypted_token')
    if not isinstance(encoded, str):
        return None
    try:
        return _dpapi(bytes.fromhex(encoded), True).decode('ascii')
    except (OSError, ValueError, UnicodeError):
        return None


def _headers(token=None):
    result = {'Content-Type': 'application/json', 'User-Agent': 'AvenaElectrical/0.6'}
    if token:
        result['Authorization'] = 'Bearer ' + token
    return result


def cloud_request(method, path, token=None, payload=None, timeout=25):
    body = None if payload is None else json.dumps(payload).encode('utf-8')
    request = urllib.request.Request(BASE + path, data=body, method=method, headers=_headers(token))
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read(4_194_304))


def activated_token(code=None):
    """Return the bound device token; on first run, exchange activation code.

    Existing DPAPI credentials are checked before any new activation attempt.
    """
    state = _read_state()
    existing = _load_token(state)
    if existing:
        try:
            status = cloud_request('GET', '/agent/status', token=existing)
            if status.get('paired'):
                return existing
        except urllib.error.HTTPError as exc:
            if exc.code != 401:
                raise
        except (urllib.error.URLError, OSError):
            # A temporary network failure must not invalidate stored credentials.
            raise
    code = code or os.environ.pop('AVENA_ACTIVATION_CODE', '')
    if not code:
        raise ValueError('کد فعال‌سازی موجود نیست. ابتدا از سایت کد بگیر و در برنامه وارد کن.')
    normalized = code.upper().replace('-', '').replace(' ', '')
    if not (len(normalized) == 20 and normalized.isalnum()):
        raise ValueError('کد فعال‌سازی باید ۲۰ حرف یا عدد باشد.')
    data = cloud_request('POST', '/api/device/activate', payload={
        'activation_code': code, 'device_id':state['device_id']})
    token = data.get('device_token')
    if not isinstance(token, str) or len(token) < 40:
        raise RuntimeError('سرور توکن اتصال معتبر برنگرداند.')
    state['encrypted_token'] = _dpapi(token.encode('ascii'), False).hex()
    _save_state(state)
    return token


def has_saved_activation():
    return bool(_load_token(_read_state()))


def local_post(method, params, token, session=None, notification=False):
    body = {'jsonrpc':'2.0','method':method,'params':params}
    if not notification:
        body['id'] = secrets.randbelow(900_000) + 100_000
    headers = {'Authorization':'Bearer '+token,'Content-Type':'application/json',
               'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-06-18'}
    if session:
        headers['Mcp-Session-Id'] = session
    req = urllib.request.Request(LOCAL, data=json.dumps(body).encode(), headers=headers, method='POST')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=18) as r:
        session = r.headers.get('Mcp-Session-Id') or session
        if r.status == 202 or notification:
            return {}, session
        if 'text/event-stream' in r.headers.get('Content-Type', ''):
            for line in r:
                if line.startswith(b'data:'):
                    try:
                        answer = json.loads(line[5:].strip())
                    except ValueError:
                        continue
                    if 'result' in answer or 'error' in answer:
                        return answer, session
            raise RuntimeError('MCP event stream empty')
        return json.loads(r.read(4_194_304)),session


def call_local(tool, token):
    if tool not in ALLOWED:
        return {'ok':False,'error':'tool_not_permitted'}
    initialized, session = local_post('initialize',{
        'protocolVersion':'2025-06-18','capabilities':{},
        'clientInfo':{'name':'Avena Electrical Windows','version':'0.6'}}, token)
    if 'result' not in initialized:
        raise RuntimeError('MCP handshake rejected')
    local_post('notifications/initialized',{},token,session,notification=True)
    response, _ = local_post('tools/call',{'name':tool,'arguments':{}},token,session)
    if 'error' in response:
        return {'ok':False,'error':'mcp_rpc_error','detail':response['error']}
    result = response.get('result', {})
    return {'ok':not result.get('isError',False),'content':result.get('content',[]),
            'structuredContent':result.get('structuredContent')}


def execute_approved_batch(operations, token: str):
    """Use a single local MCP session to add geometry after explicit on-screen consent.

    Fail closed on missing COM, disallowed DWG, ambiguous release or GUI denial.
    Partial success is reported accurately; nothing is ever automatically saved.
    """
    from app.drawing_approval import (
        TOOL_BY_TYPE, validate_plan, verify_active_drawing, approve_on_windows)
    if os.environ.get('AVENA_DRAW_ENABLED') != '1':
        return {'ok':False,'error':'drawing_disabled_in_desktop_settings'}
    try:
        plan=validate_plan(operations)
        if len(plan)>10:
            raise ValueError('Maximum 10 drawing operations per approval; send multiple batches')
        release=os.environ.get('AVENA_AUTOCAD_RELEASE','')
        allowed=os.environ.get('AVENA_ALLOWED_PATHS','')
        doc=verify_active_drawing(release,allowed)
    except (ValueError,RuntimeError,OSError) as exc:
        return {'ok':False,'error':'preflight_failed','message':str(exc)[:240]}
    try:
        accepted=approve_on_windows(doc,plan,timeout_ms=25000)
    except Exception:
        accepted=False
    if not accepted:
        return {'ok':False,'error':'rejected_by_local_user_or_timeout'}
    try:
        verify_active_drawing(release,allowed,doc)
        init,session=local_post('initialize',{
            'protocolVersion':'2025-06-18','capabilities':{},
            'clientInfo':{'name':'Avena Approved Draw','version':'0.8.1'}},token)
        if 'result' not in init:raise RuntimeError('MCP initialize failed')
        local_post('notifications/initialized',{},token,session,notification=True)
    except Exception as exc:
        return {'ok':False,'error':'local_mcp_unavailable','message':str(exc)[:240]}
    created=[]
    for number,op in enumerate(plan,1):
        try:
            verify_active_drawing(release,allowed,doc)
            reply,session=local_post('tools/call',{
                'name':TOOL_BY_TYPE[op['type']], 'arguments':op['args']},token,session)
            if reply.get('error') or reply.get('result',{}).get('isError') or 'result' not in reply:
                return {'ok':False,'error':'cad_operation_failed','failed_at':number,
                    'created_count':len(created),'created':created,
                    'detail':str(reply.get('error') or reply.get('result',{}))[:400],
                    'warning':'Some objects may exist in the active DWG; no save or rollback performed.'}
            created.append({'number':number,'type':op['type'],
                'result':str(reply['result'].get('structuredContent') or reply['result'].get('content',[]))[:350]})
        except Exception as exc:
            return {'ok':False,'error':'cad_operation_exception','failed_at':number,
                'created_count':len(created),'created':created,'message':str(exc)[:240],
                'warning':'Partial result may exist; no save or rollback performed.'}
    return {'ok':True,'drawing':doc,'created_count':len(created),'created':created,
        'saved':False,'note':'Review visually in AutoCAD and save manually if correct.'}

def execute_approved_edits(operations, local_token):
    """Safe existing-entity edits with per-batch Windows confirmation."""
    from app.edit_approval import validate_edits, TOOLS
    from app.drawing_approval import verify_active_drawing, approve_on_windows
    if os.environ.get('AVENA_DRAW_ENABLED') != '1':
        return {'ok':False,'error':'edit_disabled_in_desktop_settings'}
    try:
        edits=validate_edits(operations)
        release=os.environ.get('AVENA_AUTOCAD_RELEASE','')
        allowed=os.environ.get('AVENA_ALLOWED_PATHS','')
        doc=verify_active_drawing(release,allowed)
    except (ValueError,RuntimeError,OSError) as exc:
        return {'ok':False,'error':'preflight_failed','detail':str(exc)[:240]}
    if not approve_on_windows(doc,edits):
        return {'ok':False,'error':'rejected_by_local_user_or_timeout'}
    try:
        verify_active_drawing(release,allowed,expected_path=doc)
        response,session=local_post('initialize',{'protocolVersion':'2025-06-18','capabilities':{},
                       'clientInfo':{'name':'AvenaElectricalEdit','version':'0.9'}},local_token)
        if 'result' not in response:
            raise RuntimeError('MCP handshake failed')
        local_post('notifications/initialized',{},local_token,session,notification=True)
    except Exception as exc:
        return {'ok':False,'error':'mcp_handshake','detail':str(exc)[:240]}
    completed=[]
    for number,item in enumerate(edits,1):
        try:
            verify_active_drawing(release,allowed,expected_path=doc)
            response,session=local_post('tools/call',{'name':TOOLS[item['type']],
                                  'arguments':item['args']},local_token,session)
            if response.get('error') or response.get('result',{}).get('isError') or 'result' not in response:
                return {'ok':False,'error':'edit_failed','failed_at':number,'edited_count':len(completed),
                        'details':str(response)[:250],'saved':False}
            completed.append(item['args']['handle'])
        except Exception as exc:
            return {'ok':False,'error':'edit_exception','failed_at':number,'edited_count':len(completed),
                    'details':str(exc)[:250],'saved':False}
    return {'ok':True,'edited_count':len(completed),'handles':completed,'saved':False,
            'note':'Review changes and manually save your DWG if correct.'}

def main():
    local_token = os.environ.get('AVENA_LOCAL_MCP_TOKEN','')
    if len(local_token) < 32:
        raise RuntimeError('توکن MCP محلی موجود نیست؛ برنامه آونا را اجرا کن.')
    device_token = activated_token()
    print('[AVENA] Device paired. Outbound HTTPS enabled.', flush=True)
    delay = 3
    while True:
        try:
            job = cloud_request('GET','/agent/poll', token=device_token, timeout=28)
            delay = 3
            if job.get('idle'):
                continue
            task_id = job.get('id')
            tool = job.get('tool')
            args = job.get('arguments')
            if not isinstance(task_id,str):
                continue
            if tool == DRAW_TASK and isinstance(args,dict) and set(args)=={'operations'}:
                answer = execute_approved_batch(args['operations'],local_token)
            elif tool == EDIT_TASK and isinstance(args,dict) and set(args)=={'operations'}:
                answer = execute_approved_edits(args['operations'],local_token)
            elif tool not in ALLOWED or args not in ({},None):
                answer = {'ok':False,'error':'tool_not_permitted'}
            else:
                try:
                    answer = call_local(tool,local_token)
                except Exception as exc:
                    answer = {'ok':False,'error':'local_mcp_error','detail':str(exc)[:200]}
            cloud_request('POST','/agent/result', token=device_token,
                          payload={'id':task_id,'result':answer})
        except KeyboardInterrupt:
            return
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                raise RuntimeError('اتصال لغو شده است؛ کد را دوباره وارد کن.') from exc
            print('[AVENA] Cloud temporarily unavailable',flush=True)
        except (OSError,ValueError,TimeoutError):
            print('[AVENA] Cloud temporarily unavailable',flush=True)
        time.sleep(delay)
        delay = min(delay*2,30)

if __name__=='__main__': main()
