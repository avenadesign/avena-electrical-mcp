"""Fail-safe, read-only AutoCAD COM probe (Windows; no AutoCAD launched).

No global import of win32com: portable test environments remain importable.
Only named, versioned ProgIDs are used: never silently attach to the wrong CAD.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any
import sys

CAD_PROGIDS = {
    "2026": "AutoCAD.Application.25.1",
    "2027": "AutoCAD.Application.26",
}


@dataclass
class ProbeResult:
    release: str
    progid: str
    available: bool = False
    attached: bool = False
    cad_version: str | None = None
    application_name: str | None = None
    document_name: str | None = None
    document_path: str | None = None
    document_saved: bool | None = None
    entity_count: int | None = None
    layer_count: int | None = None
    notes: list[str] = field(default_factory=list)
    error: str | None = None

    def asdict(self) -> dict[str, Any]:
        return asdict(self)


def probe(release: str) -> ProbeResult:
    if release not in CAD_PROGIDS:
        raise ValueError("Only AutoCAD 2026/2027 are supported by this probe")
    result = ProbeResult(release=release, progid=CAD_PROGIDS[release])
    if sys.platform != "win32":
        result.error = "COM works only on Windows; probe not executed."
        return result
    try:
        import pythoncom
        import win32com.client
    except ImportError:
        result.error = "pywin32 not installed; cannot inspect the running AutoCAD."
        return result
    pythoncom.CoInitialize()
    try:
        try:
            # Important: GetActiveObject attaches only; Dispatch could start a new CAD.
            app = win32com.client.GetActiveObject(result.progid)
        except Exception as exc:
            result.error = f"No running COM object for {result.progid}: {exc}"
            return result
        result.attached = True
        result.available = True
        try:
            result.cad_version = str(app.Version)
        except Exception as exc:
            result.notes.append(f"Version unavailable: {exc}")
        expected = "25.1" if release == "2026" else "26."
        if result.cad_version is None or not result.cad_version.startswith(expected):
            result.available = False
            result.notes.append("Returned COM version does not match requested AutoCAD release; mutation must be refused.")
        try:
            result.application_name = str(app.Name)
        except Exception:
            pass
        try:
            doc = app.ActiveDocument
            result.document_name = str(doc.Name)
            result.document_path = str(doc.FullName)
            result.document_saved = bool(doc.Saved)
            result.layer_count = int(doc.Layers.Count)
            # A quick count, not an electrical project model scan.
            result.entity_count = int(doc.ModelSpace.Count)
        except Exception as exc:
            result.notes.append(f"Active document metadata unavailable: {exc}")
        result.notes.append("Read-only inspection. AutoCAD Electrical intelligent objects are not yet certified.")
        return result
    finally:
        pythoncom.CoUninitialize()


def probe_all() -> list[dict[str, Any]]:
    return [probe(version).asdict() for version in CAD_PROGIDS]
