"""Panel schedules/BOM and *non-executing* SLD sheets for upstream cad_batch.

Never claim IEC 60617 / native Electrical semantics; only generic geometry.
"""
from __future__ import annotations

import csv
import io
import math

from .panel_pro import PanelPro, audit_panel_pro


def bom(spec: PanelPro) -> dict:
    devices = [spec.incoming_device] + [f.protection for f in spec.feeders]
    groups: dict[tuple, dict] = {}
    for d in devices:
        key = (d.kind, d.manufacturer or "UNSPECIFIED", d.model or "UNSPECIFIED",
               d.rated_current_a, d.breaking_capacity_ka, d.poles, d.residual_trip_ma, d.width_modules)
        if key not in groups:
            groups[key] = {"kind": d.kind, "manufacturer": d.manufacturer,
                           "model": d.model, "rated_current_a": d.rated_current_a,
                           "breaking_capacity_ka": d.breaking_capacity_ka,
                           "poles": d.poles, "residual_trip_ma": d.residual_trip_ma,
                           "width_modules": d.width_modules, "quantity": 0, "tags": []}
        groups[key]["quantity"] += 1
        groups[key]["tags"].append(d.tag)
    for a in spec.auxiliaries:
        key = (a.kind, a.manufacturer or "UNSPECIFIED", a.model or "UNSPECIFIED",
               None, None, None, None, a.width_modules_each)
        if key not in groups:
            groups[key] = {"kind": a.kind, "manufacturer": a.manufacturer,
                           "model": a.model, "rated_current_a": None,
                           "breaking_capacity_ka": None, "poles": None,
                           "residual_trip_ma": None, "width_modules": a.width_modules_each,
                           "quantity": 0, "tags": []}
        groups[key]["quantity"] += a.quantity
        groups[key]["tags"].append(a.tag)
    rows = sorted(groups.values(), key=lambda r: (r["kind"], r["rated_current_a"] or 0, r["tags"][0]))
    cable_rows = []
    for f in spec.feeders:
        cable_rows.append({"feeder": f.id, "material": f.conductor_material,
                           "cross_section_mm2": f.conductor_cross_section_mm2,
                           "cores": f.conductor_cores, "route_length_m": f.route_length_m,
                           "estimate_only": True})
    return {"panel_id": spec.panel_id, "components": rows, "cables": cable_rows,
            "component_count": sum(x["quantity"] for x in rows),
            "engineering_approval": False,
            "limitations": ["No cable spare/wastage, terminations or procurement cost included",
                            "Manufacturer/model identifiers must be checked on actual datasheets"]}


def _csv_safe(value: object) -> str:
    """Protect CSV opened in spreadsheet software from formula injection."""
    if value is None:
        return ""
    text = str(value)
    if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r", "\n")):
        return "'" + text
    return text


def bom_csv(spec: PanelPro) -> str:
    columns = ("kind", "manufacturer", "model", "rated_current_a", "breaking_capacity_ka",
               "poles", "residual_trip_ma", "width_modules", "quantity", "tags")
    buff = io.StringIO(newline="")
    writer = csv.writer(buff, lineterminator="\r\n")
    writer.writerow(columns)
    for row in bom(spec)["components"]:
        writer.writerow([_csv_safe(",".join(row[c]) if c == "tags" else row[c]) for c in columns])
    return buff.getvalue()


def feeder_schedule_csv(spec: PanelPro) -> str:
    report = audit_panel_pro(spec)
    columns = ("id", "tag", "phase", "load_type", "connected_kw", "demand_kw",
               "design_current_a", "breaker_in_a", "ampacity_iz_a", "voltage_drop_pct",
               "fault_ka", "breaking_capacity_ka")
    buff = io.StringIO(newline="")
    writer = csv.writer(buff, lineterminator="\r\n")
    writer.writerow(columns)
    for item in report["feeders"]:
        writer.writerow([_csv_safe(item[c]) for c in columns])
    return buff.getvalue()


def panel_sld_drafts(spec: PanelPro, *, origin_x: float = 30, origin_y: float = 240, per_sheet: int = 8) -> dict:
    if not math.isfinite(origin_x) or not math.isfinite(origin_y) or max(abs(origin_x), abs(origin_y)) > 100000:
        raise ValueError("Origin out of bounds")
    if not 1 <= per_sheet <= 12:
        raise ValueError("per_sheet must be 1..12")
    sheets = []
    for start in range(0, len(spec.feeders), per_sheet):
        subset = spec.feeders[start:start + per_sheet]
        batch = []

        def add(tool, **args):
            batch.append({"tool": tool, "args": args})

        for name, color, weight in (("AV-E-POWER", 7, 35), ("AV-E-SYMBOL", 4, 25), ("AV-E-TEXT", 2, 18)):
            add("layer_create", name=name, color=color, lineweight=weight)

        def line(x1, y1, x2, y2, layer="AV-E-POWER"):
            add("entity_create_line", x1=x1, y1=y1, x2=x2, y2=y2, layer=layer)

        def text(value, x, y, height=2.5):
            add("entity_create_text", text=value, x=x, y=y, height=height, layer="AV-E-TEXT")

        text(f"{spec.panel_id} | PANEL PRELIMINARY SLD | SHEET {len(sheets) + 1}", origin_x, origin_y + 27, 3)
        text("SCHEMATIC ONLY - ENGINEER APPROVAL REQUIRED - NOT IEC 60617 SYMBOLS", origin_x, origin_y + 19, 1.8)
        text(f"INCOMER: {spec.incoming_device.tag} / {spec.incoming_device.kind} {spec.incoming_device.rated_current_a:g}A", origin_x, origin_y + 12, 2.0)
        y = origin_y - 12
        if len(subset) == 1:
            line(origin_x - 12, y, origin_x + 12, y)
        else:
            line(origin_x, y, origin_x + (len(subset) - 1) * 46, y)
        for i, f in enumerate(subset):
            x = origin_x + i * 46
            line(x, y, x, y - 11)
            add("entity_create_rectangle", x1=x - 5, y1=y - 11, x2=x + 5, y2=y - 23, layer="AV-E-SYMBOL")
            line(x, y - 23, x, y - 40)
            text(f.id, x - 9, y - 47, 2.0)
            text(f"{f.phase} / {f.connected_kw:g} kW", x - 9, y - 53, 1.65)
            text(f"{f.protection.kind} {f.protection.rated_current_a:g}A", x - 9, y - 59, 1.6)
            text(f.protection.tag, x - 9, y - 65, 1.6)
        if len(batch) > 250:
            raise RuntimeError("Exceeded upstream cad_batch 250-step ceiling")
        sheets.append({"index": len(sheets) + 1, "feeders": [f.id for f in subset],
                       "batch": {"steps": batch, "dry_run": True, "on_error": "rollback"},
                       "step_count": len(batch)})
    return {"panel_id": spec.panel_id, "kind": "non_native_geometry_only", "sheets": sheets,
            "sheet_count": len(sheets), "engineering_approval": False,
            "native_electrical_symbols": False,
            "warning": "Never apply batches without inspecting cad_batch dry_run and revision; each sheet needs a separate scratch drawing or explicitly designed layout placement.",
            "procedure": "cad_batch(dry_run=true) -> review & capture revision -> explicit user approval -> cad_batch(dry_run=false, expected_revision=..., on_error='rollback') -> save as new file"}
