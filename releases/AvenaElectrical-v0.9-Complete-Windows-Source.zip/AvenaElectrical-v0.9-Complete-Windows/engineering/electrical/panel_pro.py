"""Avena panel engineering preflight (explicit inputs, no product/code certification).

Reads user-provided ratings and evidence only. A green check is a local
arithmetic result, never a declaration of IEC 61439 assembly compliance.
"""
from __future__ import annotations

import math
from collections import Counter
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

ID = r"^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$"


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Device(Strict):
    tag: str = Field(pattern=ID)
    kind: Literal["MCB", "MCCB", "ACB", "FUSE", "RCBO", "RCD", "ISOLATOR"]
    manufacturer: str | None = Field(default=None, max_length=120)
    model: str | None = Field(default=None, max_length=120)
    rated_current_a: float = Field(gt=0, le=100000)
    breaking_capacity_ka: float | None = Field(default=None, gt=0, le=500)
    residual_trip_ma: float | None = Field(default=None, gt=0, le=100000)
    width_modules: float | None = Field(default=None, gt=0, le=100)
    poles: int = Field(ge=1, le=4)


class Auxiliary(Strict):
    """Cabinet apparatus that may appear in BOM/space/heat screening.

    This is a descriptive catalogue item, NOT a manufacturer selection engine.
    """
    tag: str = Field(pattern=ID)
    kind: Literal["SPD", "CONTACTOR", "OVERLOAD", "RELAY", "CT", "METER", "TERMINAL",
                  "ENCLOSURE", "BUSBAR", "INDICATOR", "SELECTOR", "TRANSFORMER", "OTHER"]
    quantity: int = Field(ge=1, le=1000)
    manufacturer: str | None = Field(default=None, max_length=120)
    model: str | None = Field(default=None, max_length=120)
    width_modules_each: float | None = Field(default=None, ge=0, le=1000)
    loss_w_each: float | None = Field(default=None, ge=0, le=100000)


class Feeder(Strict):
    id: str = Field(pattern=ID)
    phase: Literal["L1", "L2", "L3", "3P"]
    load_type: Literal["lighting", "socket", "motor", "hvac", "ups", "general"] = "general"
    connected_kw: float = Field(ge=0, le=100000)
    voltage_v: float = Field(gt=0, le=1000)
    power_factor: float = Field(gt=0, le=1)
    demand_factor: float = Field(gt=0, le=1)
    route_length_m: float = Field(ge=0, le=100000)
    protection: Device
    cable_corrected_ampacity_a: float | None = Field(default=None, gt=0, le=100000)
    cable_r_ohm_km: float | None = Field(default=None, ge=0, le=1000)
    cable_x_ohm_km: float | None = Field(default=None, ge=0, le=1000)
    max_voltage_drop_pct: float | None = Field(default=None, gt=0, le=100)
    prospective_fault_ka: float | None = Field(default=None, ge=0, le=500)
    earth_loop_impedance_ohm: float | None = Field(default=None, ge=0, le=10000)
    approved_max_loop_impedance_ohm: float | None = Field(default=None, gt=0, le=10000)
    conductor_material: Literal["Cu", "Al"] | None = None
    conductor_cross_section_mm2: float | None = Field(default=None, gt=0, le=10000)
    conductor_cores: int | None = Field(default=None, ge=1, le=20)
    device_loss_w: float | None = Field(default=None, ge=0, le=100000)

    @model_validator(mode="after")
    def check_pair(self):
        if (self.cable_r_ohm_km is None) != (self.cable_x_ohm_km is None):
            raise ValueError("Cable R and X must be supplied together")
        if (self.earth_loop_impedance_ohm is None) != (self.approved_max_loop_impedance_ohm is None):
            raise ValueError("Measured and approved maximum loop impedance must be supplied together")
        if self.protection.kind == "RCD" and self.protection.breaking_capacity_ka is not None:
            raise ValueError("Standalone RCD must not be treated as an overcurrent short-circuit breaker")
        return self


class PanelPro(Strict):
    panel_id: str = Field(pattern=ID)
    system: Literal["TN-S", "TN-C-S", "TT", "IT"]
    phases: Literal["3P+N", "3P", "1P+N"]
    line_voltage_v: float = Field(gt=0, le=1000)
    phase_voltage_v: float | None = Field(default=None, gt=0, le=1000)
    standard_project: str = Field(min_length=3, max_length=120)
    standard_assembly: str = Field(min_length=3, max_length=120)
    incoming_device: Device
    busbar_rated_current_a: float | None = Field(default=None, gt=0, le=100000)
    busbar_withstand_ka: float | None = Field(default=None, gt=0, le=500)
    prospective_incoming_fault_ka: float | None = Field(default=None, ge=0, le=500)
    allowed_phase_unbalance_pct: float | None = Field(default=None, ge=0, le=200)
    available_din_modules: float | None = Field(default=None, ge=0, le=10000)
    minimum_spare_din_modules: float | None = Field(default=None, ge=0, le=10000)
    enclosure_allowed_heat_w: float | None = Field(default=None, gt=0, le=100000)
    incoming_device_loss_w: float | None = Field(default=None, ge=0, le=100000)
    enclosure_ip_rating: str | None = Field(default=None, max_length=16)
    enclosure_ik_rating: str | None = Field(default=None, max_length=16)
    assembly_design_verification_ref: str | None = Field(default=None, max_length=160)
    assembly_routine_verification_ref: str | None = Field(default=None, max_length=160)
    feeders: list[Feeder] = Field(min_length=1, max_length=256)
    auxiliaries: list[Auxiliary] = Field(default_factory=list, max_length=1024)

    @model_validator(mode="after")
    def enforce_identity(self):
        ids = [f.id.casefold() for f in self.feeders]
        if len(set(ids)) != len(ids):
            raise ValueError("Feeder IDs must be unique")
        tags = ([f.protection.tag.casefold() for f in self.feeders]
                + [self.incoming_device.tag.casefold()]
                + [a.tag.casefold() for a in self.auxiliaries])
        if len(set(tags)) != len(tags):
            raise ValueError("Device TAGs must be unique")
        if self.phases == "1P+N" and any(f.phase != "L1" for f in self.feeders):
            raise ValueError("1P+N panels may only use feeder phase L1")
        if self.phases == "3P" and any(f.phase != "3P" for f in self.feeders):
            raise ValueError("3P panel without neutral cannot host L-N single-phase feeders")
        if self.phases == "3P+N" and self.phase_voltage_v is None and any(f.phase != "3P" for f in self.feeders):
            raise ValueError("3P+N with single-phase feeders requires explicit phase_voltage_v")
        return self


def _finding(status: str, code: str, target: str, message: str, evidence: dict | None = None) -> dict:
    return {"status": status, "code": code, "target": target, "message": message, "evidence": evidence or {}}


def audit_panel_pro(spec: PanelPro) -> dict:
    findings: list[dict] = []
    phases = {"L1": 0.0, "L2": 0.0, "L3": 0.0}
    details = []
    total_kw = demand_kw = 0.0

    def issue(code, target, message, evidence=None):
        findings.append(_finding("issue", code, target, message, evidence))

    def unknown(code, target, message):
        findings.append(_finding("unknown", code, target, message))

    def prelim(code, target, message, evidence=None):
        findings.append(_finding("preliminary_pass", code, target, message, evidence))

    for f in spec.feeders:
        expected_voltage = spec.line_voltage_v if f.phase == "3P" else (spec.phase_voltage_v or spec.line_voltage_v)
        if abs(f.voltage_v - expected_voltage) > max(1, 0.015 * expected_voltage):
            issue("feeder_voltage_mismatch", f.id, "Feeder voltage differs from panel's declared phase/line voltage", {"feeder_v": f.voltage_v, "panel_v": expected_voltage})
        p = f.connected_kw * f.demand_factor
        ib = p * 1000 / (f.voltage_v * f.power_factor * (math.sqrt(3) if f.phase == "3P" else 1.0))
        total_kw += f.connected_kw
        demand_kw += p
        for name in (phases if f.phase == "3P" else (f.phase,)):
            phases[name] += ib
        dev = f.protection
        if dev.kind in {"RCD", "ISOLATOR"}:
            unknown("overcurrent_protection_unverified", f.id, "RCD/isolator alone does not establish overcurrent protection; upstream protective arrangement required")
        elif ib > dev.rated_current_a + 1e-9:
            issue("ib_gt_in", f.id, "Feeder design current Ib exceeds protective-device rated current In", {"Ib": round(ib, 3), "In": dev.rated_current_a})
        else:
            prelim("ib_le_in", f.id, "Arithmetic Ib <= In condition is met")
        if f.cable_corrected_ampacity_a is None:
            unknown("corrected_iz_missing", f.id, "Corrected cable ampacity Iz and installation factors were not supplied")
        else:
            if ib > f.cable_corrected_ampacity_a + 1e-9:
                issue("ib_gt_iz", f.id, "Feeder Ib exceeds corrected conductor ampacity Iz")
            elif dev.kind not in {"RCD", "ISOLATOR"} and dev.rated_current_a > f.cable_corrected_ampacity_a + 1e-9:
                issue("in_gt_iz", f.id, "Overcurrent device In exceeds corrected conductor ampacity Iz")
            else:
                prelim("ib_in_iz_precheck", f.id, "Ib/In/Iz arithmetic precheck met; I2/manufacturer and cable installation still need validation")
        drop_v = drop_pct = None
        if f.cable_r_ohm_km is None:
            unknown("rx_missing", f.id, "Cable R/X at operating temperature were not provided")
        else:
            sin_phi = math.sqrt(max(0.0, 1 - f.power_factor ** 2))
            drop_v = (math.sqrt(3) if f.phase == "3P" else 2) * ib * f.route_length_m / 1000 * (f.cable_r_ohm_km * f.power_factor + f.cable_x_ohm_km * sin_phi)
            drop_pct = 100 * drop_v / f.voltage_v
            if f.max_voltage_drop_pct is None:
                unknown("drop_limit_missing", f.id, "Project-specific voltage-drop limit missing")
            elif drop_pct > f.max_voltage_drop_pct + 1e-9:
                issue("voltage_drop_exceeded", f.id, "Voltage drop exceeds the declared limit", {"drop_pct": round(drop_pct, 4), "limit_pct": f.max_voltage_drop_pct})
            else:
                prelim("voltage_drop_precheck", f.id, "Feeder voltage-drop arithmetic under the declared limit")
        if f.prospective_fault_ka is None:
            unknown("prospective_fault_missing", f.id, "Prospective fault at feeder protective device missing")
        elif dev.kind in {"RCD", "ISOLATOR"}:
            unknown("device_breaking_not_applicable", f.id, "RCD/isolator is not evaluated as a circuit-breaker")
        elif dev.breaking_capacity_ka is None:
            unknown("device_breaking_capacity_missing", f.id, "Device breaking rating at the system voltage missing")
        elif f.prospective_fault_ka > dev.breaking_capacity_ka + 1e-9:
            issue("breaking_capacity_insufficient", f.id, "Prospective fault exceeds declared device breaking capacity")
        else:
            prelim("breaking_capacity_precheck", f.id, "Numerical fault/breaking-capacity comparison met; Icu/Ics, voltage and coordination must be verified")
        if f.earth_loop_impedance_ohm is None:
            unknown("loop_impedance_missing", f.id, "Earth fault loop / disconnection verification missing")
        elif f.earth_loop_impedance_ohm > f.approved_max_loop_impedance_ohm + 1e-9:
            issue("earth_loop_threshold_exceeded", f.id, "Measured loop impedance exceeds user-supplied approved threshold")
        else:
            prelim("loop_impedance_precheck", f.id, "Measured loop impedance below user-supplied threshold only")
        if f.load_type in {"motor", "ups"}:
            unknown("dynamic_load_not_checked", f.id, "Start/inrush, harmonics and special protection requirements are not assessed")
        if f.conductor_cross_section_mm2 is None or f.conductor_material is None or f.conductor_cores is None:
            unknown("cable_schedule_incomplete", f.id, "Material/section/core count missing for cable schedule")
        details.append({
            "id": f.id, "tag": dev.tag, "phase": f.phase, "load_type": f.load_type,
            "connected_kw": round(f.connected_kw, 4), "demand_kw": round(p, 4),
            "design_current_a": round(ib, 4), "breaker_in_a": dev.rated_current_a,
            "ampacity_iz_a": f.cable_corrected_ampacity_a,
            "voltage_drop_v": round(drop_v, 4) if drop_v is not None else None,
            "voltage_drop_pct": round(drop_pct, 4) if drop_pct is not None else None,
            "fault_ka": f.prospective_fault_ka, "breaking_capacity_ka": dev.breaking_capacity_ka,
        })

    max_phase = max(phases.values())
    mean_phase = sum(phases.values()) / 3
    imbalance = 100 * (max_phase - min(phases.values())) / mean_phase if mean_phase else None
    if spec.system == "TT" and not any(d.kind in {"RCD", "RCBO"}
                                         and d.residual_trip_ma is not None
                                         for d in [spec.incoming_device] + [f.protection for f in spec.feeders]):
        unknown("tt_residual_protection_not_documented", spec.panel_id,
                "TT earth-fault/residual protection strategy not documented in devices list; upstream protection may be external")
    for f in spec.feeders:
        if f.protection.kind in {"RCD", "RCBO"} and f.protection.residual_trip_ma is None:
            unknown("residual_trip_rating_missing", f.id, "RCD/RCBO residual-current rating missing")
    if spec.phases == "3P+N":
        if spec.allowed_phase_unbalance_pct is None:
            unknown("phase_imbalance_limit_missing", spec.panel_id, "Project allowable current imbalance not declared")
        elif imbalance is not None and imbalance > spec.allowed_phase_unbalance_pct + 1e-9:
            issue("phase_imbalance_exceeded", spec.panel_id, "Peak-to-peak phase imbalance exceeds project's specified tolerance")
        else:
            prelim("phase_imbalance_precheck", spec.panel_id, "Declared phase-current imbalance threshold met")
        unknown("neutral_harmonics_not_checked", spec.panel_id, "Neutral current and triplen harmonic heating cannot be inferred from fundamental phase currents")
    if max_phase > spec.incoming_device.rated_current_a + 1e-9:
        issue("incoming_rating_below_phase_current", spec.panel_id, "Maximum phase design current exceeds incoming-device rated current")
    else:
        prelim("incoming_current_precheck", spec.panel_id, "Maximum phase design current <= incomer In (not a loading/diversity certification)")
    if spec.busbar_rated_current_a is None:
        unknown("busbar_current_rating_missing", spec.panel_id, "Busbar current rating and installation/temperature correction missing")
    elif max_phase > spec.busbar_rated_current_a + 1e-9:
        issue("busbar_current_exceeded", spec.panel_id, "Peak phase current exceeds busbar rating")
    else:
        prelim("busbar_current_precheck", spec.panel_id, "Peak phase current <= declared busbar current rating")
    if spec.prospective_incoming_fault_ka is None:
        unknown("incoming_fault_missing", spec.panel_id, "Incoming prospective fault current missing")
    else:
        fault = spec.prospective_incoming_fault_ka
        if spec.incoming_device.kind not in {"ISOLATOR", "RCD"}:
            if spec.incoming_device.breaking_capacity_ka is None:
                unknown("incoming_breaking_capacity_missing", spec.panel_id, "Incomer breaking capacity absent")
            elif fault > spec.incoming_device.breaking_capacity_ka + 1e-9:
                issue("incoming_breaking_capacity_insufficient", spec.panel_id, "Incoming fault exceeds device breaking capacity")
            else:
                prelim("incoming_breaking_capacity_precheck", spec.panel_id, "Numerical incomer fault comparison met; assembly verification remains separate")
        else:
            unknown("incoming_short_circuit_protection_unverified", spec.panel_id, "Incomer is not a circuit-breaker; actual upstream protection must be supplied")
        if spec.busbar_withstand_ka is None:
            unknown("busbar_short_circuit_rating_missing", spec.panel_id, "Busbar short-circuit withstand rating and time basis absent")
        elif fault > spec.busbar_withstand_ka + 1e-9:
            issue("busbar_fault_rating_exceeded", spec.panel_id, "Prospective fault exceeds declared busbar withstand value")
        else:
            prelim("busbar_fault_precheck", spec.panel_id, "Numerical fault/busbar withstand comparison met; duration and peak withstand not checked")
    if spec.available_din_modules is None:
        unknown("din_capacity_missing", spec.panel_id, "DIN rail width / available positions not declared")
    else:
        width = [spec.incoming_device.width_modules] + [f.protection.width_modules for f in spec.feeders]
        if any(w is None for w in width) or any(a.width_modules_each is None for a in spec.auxiliaries):
            unknown("device_width_missing", spec.panel_id, "Some device DIN widths missing; capacity cannot be verified")
        else:
            used = sum(width) + sum(a.width_modules_each * a.quantity for a in spec.auxiliaries)
            spare = max(0, spec.available_din_modules - used)
            if used > spec.available_din_modules + 1e-9:
                issue("din_capacity_exceeded", spec.panel_id, "Device module-width sum exceeds declared usable DIN positions", {"used": used, "capacity": spec.available_din_modules})
            elif spec.minimum_spare_din_modules is not None and spare < spec.minimum_spare_din_modules - 1e-9:
                issue("spare_modules_insufficient", spec.panel_id, "DIN reserve below declared project target", {"spare": spare, "minimum": spec.minimum_spare_din_modules})
            else:
                prelim("din_capacity_precheck", spec.panel_id, "DIN positions arithmetic precheck met; no physical layout/heat/clearance verification", {"used": used, "spare": spare})
    losses = [spec.incoming_device_loss_w] + [f.device_loss_w for f in spec.feeders]
    if (spec.enclosure_allowed_heat_w is None or any(x is None for x in losses)
            or any(a.loss_w_each is None for a in spec.auxiliaries)):
        unknown("thermal_evidence_missing", spec.panel_id, "Enclosure manufacturer dissipation allowance and device loss data required")
    else:
        heat = sum(losses) + sum(a.loss_w_each * a.quantity for a in spec.auxiliaries)
        if heat > spec.enclosure_allowed_heat_w + 1e-9:
            issue("declared_heat_budget_exceeded", spec.panel_id, "Sum of declared device losses exceeds declared enclosure allowance", {"loss_w": round(heat, 3), "allowed_w": spec.enclosure_allowed_heat_w})
        else:
            prelim("heat_budget_screen", spec.panel_id, "Heat budget screening only; not IEC 61439 temperature-rise verification")
    for attr, code in (("enclosure_ip_rating", "ip_rating_missing"), ("enclosure_ik_rating", "ik_rating_missing"),
                       ("assembly_design_verification_ref", "design_verification_missing"),
                       ("assembly_routine_verification_ref", "routine_verification_missing")):
        if not getattr(spec, attr):
            unknown(code, spec.panel_id, "Manufacturer rating or verified evidence reference not supplied")
    unknown("protective_selectivity_not_checked", spec.panel_id, "Selectivity/coordination must be checked from manufacturer curves/tables")
    unknown("assembly_verification_not_automatic", spec.panel_id, "IEC 61439 construction, temperature rise, dielectric, protective circuit, short-circuit verification and routine checks require documented evidence")
    return {
        "schema": "avena-panel-pro/0.3", "panel_id": spec.panel_id,
        "engineering_approval": False, "status": "issues_found" if any(f["status"] == "issue" for f in findings) else "preliminary_only",
        "total_connected_kw": round(total_kw, 4), "total_demand_kw": round(demand_kw, 4),
        "phase_current_a": {k: round(v, 4) for k, v in phases.items()},
        "peak_phase_current_a": round(max_phase, 4),
        "phase_peak_to_peak_unbalance_pct": round(imbalance, 4) if imbalance is not None else None,
        "feeders": details,
        "counts": dict(Counter(f["status"] for f in findings)),
        "findings": findings,
        "scope": "Arithmetic preflight and missing-evidence detection only; never engineering approval",
    }
