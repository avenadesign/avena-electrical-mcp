"""Non-mutating MCP surface, additive to the existing FastMCP server."""

from __future__ import annotations

from .audit import audit_panel, audit_riser
from .sld import plan_sld
from .spec import PanelSpec, RiserSpec
from .panel_pro_mcp import register_panel_pro_tools


def register_electrical_tools(mcp):
    """Register read-only specialty tools; do not mutate the active CAD seat."""
    register_panel_pro_tools(mcp)

    @mcp.tool(
        name="electrical_panel_audit",
        description="Audit electrical panel loads, currents, phase balance, voltage drop and known/unknown electrical safety checks.",
        annotations={"readOnlyHint": True},
        tags={"electrical", "analysis"},
    )
    def electrical_panel_audit(spec: dict) -> dict:
        """Validate an explicit preliminary electrical panel specification."""
        return audit_panel(PanelSpec.model_validate(spec))

    @mcp.tool(
        name="electrical_riser_audit",
        description="Check a radial panel riser for missing upstream panels, cycles, duplicate IDs and root count.",
        annotations={"readOnlyHint": True},
        tags={"electrical", "analysis"},
    )
    def electrical_riser_audit(spec: dict) -> dict:
        """Read-only topology preflight, not electrical design certification."""
        return audit_riser(RiserSpec.model_validate(spec))

    @mcp.tool(
        name="electrical_sld_plan",
        description="Generate a non-mutating cad_batch plan for a generic geometric single-line diagram draft (NOT native Electrical objects).",
        annotations={"readOnlyHint": True},
        tags={"electrical", "planning"},
    )
    def electrical_sld_plan(spec: dict, origin_x: float = 20, origin_y: float = 240) -> dict:
        """Prepare, but do not execute, a CAD plan for an electrical SLD sketch."""
        return plan_sld(PanelSpec.model_validate(spec), origin_x, origin_y)

    @mcp.tool(
        name="electrical_com_inventory",
        description="Read-only AutoCAD 2026/2027 live COM inventory of model-space blocks, layers and attributes; explicitly incomplete when capped. NOT native Electrical project semantics.",
        annotations={"readOnlyHint": True},
        tags={"electrical", "analysis"},
    )
    async def electrical_com_inventory(release: str = "2027", limit: int = 400) -> dict:
        import anyio
        from app.com_inventory import inventory
        return await anyio.to_thread.run_sync(inventory, release, limit)
