"""Plan a deliberately simple SLD *draft* using AutoCAD MCP Pro's existing tools.

This never executes CAD operations. The returned batch must be dry-run, reviewed,
then applied against the same document revision by cad_batch.
Native AutoCAD Electrical intelligence (wire networks, project database, tags)
is NOT implied by this geometric draft.
"""

from __future__ import annotations

import math

from .audit import audit_panel
from .spec import PanelSpec

MAX_BATCH_STEPS = 250  # Current AutoCAD MCP Pro v1.7.0 ceiling.


def plan_sld(spec: PanelSpec, origin_x: float = 20, origin_y: float = 240) -> dict:
    if not all(math.isfinite(v) and abs(v) <= 100_000 for v in (origin_x, origin_y)):
        raise ValueError("Origin must be finite and within +/-100000 drawing units")
    steps: list[dict] = []

    def line(x1: float, y1: float, x2: float, y2: float, layer: str = "AV-E-POWER"):
        steps.append({"tool": "entity_create_line", "args": {
            "x1": x1, "y1": y1, "x2": x2, "y2": y2, "layer": layer,
        }})

    def label(text: str, x: float, y: float, height: float = 2.5):
        steps.append({"tool": "entity_create_text", "args": {
            "text": text, "x": x, "y": y, "height": height, "layer": "AV-E-TEXT",
        }})

    # Intended for a NEW or verified target drawing; these are not blanket layer resets.
    for name, color, weight in (("AV-E-POWER", 7, 35), ("AV-E-SYMBOL", 4, 25), ("AV-E-TEXT", 2, 18)):
        steps.append({"tool": "layer_create", "args": {
            "name": name, "color": color, "lineweight": weight,
        }})
    label(f"PRELIMINARY SLD - {spec.panel_id} - NOT FOR CONSTRUCTION", origin_x, origin_y + 22, 3.2)
    label("SCHEMATIC GEOMETRY ONLY - NO ELECTRICAL PROJECT DATABASE", origin_x, origin_y + 14, 2.0)

    for row_start in range(0, len(spec.circuits), 8):
        row = row_start // 8
        group = spec.circuits[row_start:row_start + 8]
        row_y = origin_y - row * 72
        line(origin_x, row_y, origin_x + (len(group) - 1) * 40, row_y)
        for col, circuit in enumerate(group):
            x = origin_x + col * 40
            line(x, row_y, x, row_y - 11)
            # Generic rectangular switching-device placeholder, not an IEC 60617 symbol.
            steps.append({"tool": "entity_create_rectangle", "args": {
                "x1": x - 4, "y1": row_y - 11, "x2": x + 4,
                "y2": row_y - 20, "layer": "AV-E-SYMBOL",
            }})
            line(x, row_y - 20, x, row_y - 31)
            label(circuit.id, x - 7, row_y - 38)
            label(circuit.phase, x - 7, row_y - 44, 2.1)
            label(f"{circuit.input_load_kw:g} kW", x - 7, row_y - 50, 2.1)
    if len(steps) > MAX_BATCH_STEPS:
        raise ValueError(f"Batch has {len(steps)} steps; upstream ceiling is {MAX_BATCH_STEPS}")
    return {
        "kind": "geometric_sld_draft", "panel_id": spec.panel_id,
        "requires_explicit_preview_and_approval": True,
        "requires_existing_document_with_mm_units": True,
        "native_electrical_symbols": False, "native_wire_networks": False,
        "warning": "This is NOT a code-compliant SLD or an AutoCAD Electrical intelligent schematic.",
        "batch": {
            "steps": steps, "dry_run": True, "on_error": "rollback",
        },
        "how_to_apply": (
            "1) On an owned/scratch drawing, call cad_batch with batch.steps and dry_run=true. "
            "2) Review preview and electrical_panel_audit. "
            "3) If approved, call cad_batch with identical steps, dry_run=false, "
            "on_error=rollback and expected_revision from the dry-run preview. "
            "4) Verify geometry, then save to a new filename."
        ),
        "step_count": len(steps),
        "preflight": audit_panel(spec),
    }
