"""Read-only specialized panel tools for existing AutoCAD MCP Pro server."""
from __future__ import annotations

from .panel_pro import PanelPro, audit_panel_pro
from .panel_pro_outputs import bom, feeder_schedule_csv, panel_sld_drafts


def register_panel_pro_tools(mcp) -> None:
    @mcp.tool(name="electrical_panel_pro_audit",
              description="Expert LV switchboard preflight: feeder loading, Ib/In/Iz, voltage drop, prospective fault versus breaking capacity, busbar, DIN space, declared thermal budget, loop impedance and IEC 61439 evidence gaps. Never certifies design.",
              annotations={"readOnlyHint": True}, tags={"electrical", "analysis"})
    def electrical_panel_pro_audit(spec: dict) -> dict:
        return audit_panel_pro(PanelPro.model_validate(spec))

    @mcp.tool(name="electrical_panel_pro_bom",
              description="Read-only breaker/incomer grouped bill of materials and cable schedule with missing procurement evidence explicitly marked.",
              annotations={"readOnlyHint": True}, tags={"electrical", "analysis"})
    def electrical_panel_pro_bom(spec: dict) -> dict:
        return bom(PanelPro.model_validate(spec))

    @mcp.tool(name="electrical_panel_pro_feeder_csv",
              description="Read-only CSV string for feeder panel schedule, with spreadsheet formula-injection protection.",
              annotations={"readOnlyHint": True}, tags={"electrical", "analysis"})
    def electrical_panel_pro_feeder_csv(spec: dict) -> str:
        return feeder_schedule_csv(PanelPro.model_validate(spec))

    @mcp.tool(name="electrical_panel_pro_sld_pages",
              description="Prepare non-mutating separated cad_batch plans for preliminary power distribution single-line diagram pages. Geometric placeholders, no native AutoCAD Electrical wires. Explicit approval required.",
              annotations={"readOnlyHint": True}, tags={"electrical", "planning"})
    def electrical_panel_pro_sld_pages(spec: dict, origin_x: float = 30, origin_y: float = 240, per_sheet: int = 8) -> dict:
        return panel_sld_drafts(PanelPro.model_validate(spec), origin_x=origin_x, origin_y=origin_y, per_sheet=per_sheet)
