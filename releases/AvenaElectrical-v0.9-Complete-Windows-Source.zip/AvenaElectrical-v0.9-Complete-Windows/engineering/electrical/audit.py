"""Deterministic preliminary power-circuit checks (not a code-compliance certificate)."""

from __future__ import annotations

import math

from .spec import PanelSpec, RiserSpec


def _finding(severity: str, code: str, target: str, detail: str) -> dict:
    return {"severity": severity, "code": code, "target": target, "detail": detail}


def audit_panel(spec: PanelSpec) -> dict:
    findings: list[dict] = []
    phases = {"L1": 0.0, "L2": 0.0, "L3": 0.0}
    circuits: list[dict] = []
    total_input_kw = total_demand_kw = 0.0
    for c in spec.circuits:
        p_kw = c.input_load_kw * c.demand_factor
        current = p_kw * 1000 / (c.nominal_voltage_v * c.power_factor)
        if c.phase == "3P":
            current /= math.sqrt(3)
            for key in phases:
                phases[key] += current
        else:
            phases[c.phase] += current
        total_input_kw += c.input_load_kw
        total_demand_kw += p_kw
        if c.protective_device_a is None:
            findings.append(_finding("unknown", "device_rating_missing", c.id, "Device rating not provided"))
        elif current > c.protective_device_a + 1e-9:
            findings.append(_finding("issue", "ib_gt_in", c.id, "Calculated Ib exceeds In"))
        if c.corrected_ampacity_a is None:
            findings.append(_finding("unknown", "ampacity_missing", c.id, "Corrected cable ampacity Iz not provided"))
        else:
            if current > c.corrected_ampacity_a + 1e-9:
                findings.append(_finding("issue", "ib_gt_iz", c.id, "Calculated Ib exceeds corrected Iz"))
            if c.protective_device_a is not None and c.protective_device_a > c.corrected_ampacity_a + 1e-9:
                findings.append(_finding("issue", "in_gt_iz", c.id, "Protective device In exceeds corrected Iz; verify protection coordination"))
        drop_v = drop_pct = None
        if c.cable_r_ohm_per_km is None or c.cable_x_ohm_per_km is None:
            findings.append(_finding("unknown", "impedance_missing", c.id, "Supply cable R and X at design operating conditions for voltage drop"))
        else:
            sin_phi = math.sqrt(max(0.0, 1 - c.power_factor**2))
            factor = math.sqrt(3) if c.phase == "3P" else 2.0
            drop_v = factor * current * (c.length_m / 1000) * (
                c.cable_r_ohm_per_km * c.power_factor
                + c.cable_x_ohm_per_km * sin_phi
            )
            drop_pct = 100 * drop_v / c.nominal_voltage_v
            if c.permitted_voltage_drop_percent is None:
                findings.append(_finding("unknown", "voltage_drop_limit_missing", c.id, "Design voltage-drop threshold not provided"))
            elif drop_pct > c.permitted_voltage_drop_percent + 1e-9:
                findings.append(_finding("issue", "voltage_drop_exceeded", c.id, "Calculated voltage drop exceeds specified limit"))
        circuits.append({
            "id": c.id, "phase": c.phase,
            "design_current_a": round(current, 4),
            "demand_load_kw": round(p_kw, 4),
            "voltage_drop_v": round(drop_v, 4) if drop_v is not None else None,
            "voltage_drop_percent": round(drop_pct, 4) if drop_pct is not None else None,
        })
    balance = None
    peak = max(phases.values())
    mean = sum(phases.values()) / 3
    if mean > 0:
        balance = 100 * (peak - min(phases.values())) / mean
        if spec.max_phase_current_unbalance_percent is None:
            findings.append(_finding("unknown", "unbalance_limit_missing", spec.panel_id, "Permitted phase-current imbalance not provided"))
        elif balance > spec.max_phase_current_unbalance_percent + 1e-9:
            findings.append(_finding("issue", "phase_unbalance_exceeded", spec.panel_id, "Phase-current imbalance exceeds project threshold"))
    # These require source/installation-specific data. Do not represent them as passed.
    for code, detail in (
        ("short_circuit_not_checked", "Prospective fault current and protective-device breaking capacity not checked"),
        ("disconnection_not_checked", "Automatic disconnection, earth-fault loop impedance and RCD not checked"),
        ("installation_not_checked", "Earthing system, installation method, conductor sizing and local code compliance not checked"),
    ):
        findings.append(_finding("unknown", code, spec.panel_id, detail))
    return {
        "panel_id": spec.panel_id, "engineering_approval": False,
        "scope": "Preliminary calculated load / voltage-drop / basic protective coordination only",
        "total_connected_kw": round(total_input_kw, 4),
        "total_demand_kw": round(total_demand_kw, 4),
        "phase_current_a": {p: round(v, 4) for p, v in phases.items()},
        "phase_unbalance_percent": round(balance, 4) if balance is not None else None,
        "circuits": circuits, "findings": findings,
        "issue_count": sum(f["severity"] == "issue" for f in findings),
        "unknown_count": sum(f["severity"] == "unknown" for f in findings),
    }


def audit_riser(spec: RiserSpec) -> dict:
    parent = {node.panel_id.casefold(): node.upstream_id.casefold() if node.upstream_id else None for node in spec.nodes}
    names = {node.panel_id.casefold(): node.panel_id for node in spec.nodes}
    findings = []
    for node, upstream in parent.items():
        if upstream is not None and upstream not in parent:
            findings.append(_finding("issue", "unknown_upstream", names[node], f"Unknown upstream panel: {upstream}"))
        if upstream == node:
            findings.append(_finding("issue", "self_connection", names[node], "Panel references itself"))
    roots = [names[n] for n, upstream in parent.items() if upstream is None]
    if len(roots) != 1:
        findings.append(_finding("issue", "root_count", "riser", "Radial riser requires exactly one source/root"))
    # Iterative traversal, avoids recursion depth and reports cycles explicitly.
    done = set()
    for start in parent:
        if start in done:
            continue
        local = {}
        current = start
        while current is not None and current in parent and current not in done:
            if current in local:
                cycle = list(local)[local[current]:]
                findings.append(_finding("issue", "cycle", names[start], "Cycle: " + " -> ".join(names[n] for n in cycle)))
                break
            local[current] = len(local)
            current = parent[current]
        done.update(local)
    return {"kind": "radial_riser", "node_count": len(parent), "roots": roots,
            "findings": findings, "valid_topology": not findings,
            "engineering_approval": False, "note": "Topology only; no fault, coordination or loading checks"}
