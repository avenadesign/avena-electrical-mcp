"""Explicit electrical data contracts. Never infer engineering ratings silently."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Circuit(_Strict):
    id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")
    phase: Literal["L1", "L2", "L3", "3P"]
    input_load_kw: float = Field(gt=0, le=100000)
    nominal_voltage_v: float = Field(gt=0, le=1000)
    power_factor: float = Field(gt=0, le=1)
    demand_factor: float = Field(gt=0, le=1)
    length_m: float = Field(ge=0, le=100000)
    # Resistance must be at an explicitly agreed conductor operating temperature.
    cable_r_ohm_per_km: float | None = Field(default=None, ge=0, le=1000)
    cable_x_ohm_per_km: float | None = Field(default=None, ge=0, le=1000)
    protective_device_a: float | None = Field(default=None, gt=0, le=100000)
    corrected_ampacity_a: float | None = Field(default=None, gt=0, le=100000)
    permitted_voltage_drop_percent: float | None = Field(default=None, gt=0, le=100)

    @model_validator(mode="after")
    def check_phase_voltage(self):
        # No voltage assumptions; merely ensure a single phase is not tagged 3P.
        if self.phase == "3P" and self.nominal_voltage_v < 100:
            raise ValueError("3P circuit voltage must be explicit and realistic")
        return self


class PanelSpec(_Strict):
    panel_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")
    circuits: list[Circuit] = Field(min_length=1, max_length=32)
    max_phase_current_unbalance_percent: float | None = Field(default=None, ge=0, le=100)

    @model_validator(mode="after")
    def unique_circuit_ids(self):
        names = [c.id.casefold() for c in self.circuits]
        if len(set(names)) != len(names):
            raise ValueError("Circuit IDs must be unique (case-insensitive)")
        return self


class RiserNode(_Strict):
    panel_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")
    upstream_id: str | None = Field(default=None, pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]{0,29}$")


class RiserSpec(_Strict):
    nodes: list[RiserNode] = Field(min_length=1, max_length=256)

    @model_validator(mode="after")
    def unique_nodes(self):
        names = [n.panel_id.casefold() for n in self.nodes]
        if len(set(names)) != len(names):
            raise ValueError("Panel IDs must be unique (case-insensitive)")
        return self
